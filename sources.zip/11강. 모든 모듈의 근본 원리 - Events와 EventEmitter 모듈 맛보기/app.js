/**
 * ========================================================================
 * [11강: Node.js의 심장 박동 - Events와 EventEmitter 모듈]
 * ========================================================================
 * * 1. EventEmitter의 목적
 * - 사건(Event)을 발생시키고(Emit), 그 사건에 반응(Listen)하는 구조 구축
 * - 싱글 스레드 환경에서 멈춤 없는(Non-Blocking) 비동기 처리 구현의 핵심
 * * 2. 핵심 키워드
 * - Emit: 신호를 방출하다 (주방장이 진동벨을 누르는 행위)
 * - On / Once: 신호를 감지하다 (벨이 울리면 음식을 가져가는 행위)
 */

import EventEmitter from 'node:events';

// [PART 1: 기초적인 이벤트 방출과 감지]
const myEmitter = new EventEmitter();

// 이벤트 리스너 등록 (신호를 기다림)
myEmitter.on('orderComplete', () => {
    console.log('🔔 알림: 고객님의 주문이 완료되었습니다. 음식을 수령해 주세요!');
});

console.log('일꾼: 주문을 접수하고 다른 손님의 주문을 받는 중...');

// 이벤트 발생 (신호를 쏨)
myEmitter.emit('orderComplete');

// -------------------------------------------------------------------------
// [PART 2: 데이터 전달과 실행 횟수 통제]
const serverEmitter = new EventEmitter();

// .once(): 최초 한 번만 실행되는 보안/설정 알림에 유용
serverEmitter.once('userLogin', (username, ipAddress) => {
    console.log(`🛡️ [보안] ${username}님 최초 로그인 감지 (접속 IP: ${ipAddress})`);
});

// .on(): 반복되는 데이터 수신 처리에 유용
serverEmitter.on('dataReceived', (dataSize) => {
    console.log(`📦 [통신] ${dataSize} 바이트의 데이터를 수신했습니다.`);
});

// 데이터와 함께 신호 방출
serverEmitter.emit('userLogin', '홍길동', '192.168.0.1');
serverEmitter.emit('userLogin', '홍길동', '192.168.0.1'); // .once이므로 무시됨

serverEmitter.emit('dataReceived', 1024);
serverEmitter.emit('dataReceived', 2048);

/**
 * [💡 강의 핵심 요약]
 * - Node.js의 fs, http 모듈 등 대부분의 기능은 이 EventEmitter를 상속받았습니다.
 * - "작업이 끝났다"는 신호를 주고받는 이 방식 덕분에 Node.js는 가볍고 빠릅니다.
 * - 12강에서는 이 원리를 활용해 실제로 웹 브라우저와 통신하는 HTTP 모듈을 배웁니다.
 */