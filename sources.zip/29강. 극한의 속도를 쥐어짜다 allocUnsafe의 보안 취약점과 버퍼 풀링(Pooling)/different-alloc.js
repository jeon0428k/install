/**
 * [29강 실습 통합본] Node.js 버퍼 할당 전략: alloc vs allocUnsafe vs allocUnsafeSlow
 * 주제: 메모리 초기화(Zero-fill), 시스템 콜(System Call), 버퍼 풀링(Pooling)
 */

import { Buffer } from 'node:buffer';

// =================================================================
// 1. Buffer.alloc(size): 안전제일주의 (기본 할당)
// =================================================================
console.log("--- 1. Buffer.alloc: 안전하지만 무거운 초기화 ---");

// OS에 시스템 콜을 보내 메모리를 받고, 모든 칸을 0으로 채우는(Zero-fill) '디지털 파쇄' 과정을 거칩니다.
// CPU가 2048번 덮어쓰기 연산을 수행하므로 가장 느리지만, 보안상 완벽합니다.
const safeBuffer = Buffer.alloc(2048);
console.log("Safe Buffer (모두 0):", safeBuffer); 
console.log("");


// =================================================================
// 2. Buffer.allocUnsafe(size): 광속 할당과 보안 리스크
// =================================================================
console.log("--- 2. Buffer.allocUnsafe: 초기화 없는 날것의 메모리 ---");

// 0으로 지우는 과정을 생략하고 OS가 준 공간을 그대로 던져줍니다.
// 성능은 압도적이지만, 이전 프로그램의 '쓰레기 데이터(비밀번호 등)'가 노출될 수 있습니다.
const unsafeBuffer = Buffer.allocUnsafe(2048);

// [보안 테스트] 날것의 메모리 내부에 남은 찌꺼기 데이터 확인
let leakCount = 0;
for (let i = 0; i < unsafeBuffer.length; i++) {
  if (unsafeBuffer[i] !== 0) {
    if (leakCount < 5) { // 너무 많을 수 있으니 5개만 출력
        console.log(`[경고] 인덱스 ${i} 위치에 쓰레기 데이터 발견: ${unsafeBuffer[i].toString(2)}`);
    }
    leakCount++;
  }
}
console.log(`총 ${leakCount}바이트의 이전 데이터 흔적이 발견되었습니다.`);
console.log("");


// =================================================================
// 3. 버퍼 풀링(Buffer Pooling)의 마법 (성능의 핵심)
// =================================================================
console.log("--- 3. 버퍼 풀링(Pooling) 메커니즘 확인 ---");

/**
 * [버퍼 풀링이란?]
 * Node.js는 실행 시 8KB(8192바이트)를 미리 할당(수영장)해둡니다.
 * allocUnsafe 사용 시, 풀 크기의 절반(4KB)보다 작은 요청은 시스템 콜 없이 
 * 미리 준비된 풀에서 메모리를 쓱 잘라 즉시 내어줍니다. (광속의 비결)
 */

console.log(`Node.js 공용 버퍼 풀 크기: ${Buffer.poolSize} bytes`);

// [CPU 최적화 비트 연산] 2로 나누는 가장 빠른 방법: 비트 우측 시프트(>>> 1)
// CPU 내부의 시프트 레지스터를 사용하여 물리적으로 비트를 밀어버립니다.
const halfPool = Buffer.poolSize >>> 1; 
console.log(`풀링 적용 기준점(풀의 절반): ${halfPool} bytes`);
console.log("");


// =================================================================
// 4. Buffer.allocUnsafeSlow(size): 파편화 방지 전략
// =================================================================
console.log("--- 4. Buffer.allocUnsafeSlow: 독립적인 고독한 할당 ---");

// 크기가 작아도(2048 < 4096) 공용 풀을 절대 쓰지 않고 OS에 새로 요청합니다.
// 수명이 매우 긴 데이터(환경설정, 암호 키 등)가 공용 풀을 차지하여 
// 메모리 파편화(Fragmentation)를 일으키는 것을 막기 위한 고도의 최적화 전략입니다.
const slowBuffer = Buffer.allocUnsafeSlow(2048);
console.log("Slow Buffer 할당 완료 (독립적 메모리 공간 점유)");


// =================================================================
// [총정리 시각화 주석]
// =================================================================
/*
  ▶ Buffer.alloc: 
     - 경로: 유저 모드 -> 커널 모드(시스템 콜) -> RAM 찾기 -> 0으로 닦기(Zeroing) -> 반환
     - 특징: 느림, 보안 최상

  ▶ Buffer.allocUnsafe: 
     - 경로: 유저 모드(이미 빌려온 8KB 풀에서 썰어주기) -> 즉시 반환
     - 특징: 광속, 보안 위험(반드시 새 데이터로 꽉 채워야 함)

  ▶ Buffer.allocUnsafeSlow: 
     - 경로: 유저 모드 -> 커널 모드(시스템 콜) -> 독립 RAM 확보 -> 반환
     - 특징: 느림, 메모리 파편화 방지(장기 생존 데이터용)
*/