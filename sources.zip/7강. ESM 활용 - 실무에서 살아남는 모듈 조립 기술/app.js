/**
 * ========================================================================
 * [7강: ESM 활용 - 실무에서 살아남는 모듈 조립 기술 강의 코드 정리]
 * ========================================================================
 */

// ---------------------------------------------------------
// 1. 이름 충돌 방지: 별칭(as, Alias) 사용법
// ---------------------------------------------------------
// apple.js -> export function getInfo() { ... }
// banana.js -> export function getInfo() { ... }

import { getInfo as getAppleInfo } from './apple.js';
import { getInfo as getBananaInfo } from './banana.js';

getAppleInfo();  // "이것은 사과에 대한 정보입니다."
getBananaInfo(); // "이것은 바나나에 대한 정보입니다."


// ---------------------------------------------------------
// 2. 와일드카드(Wildcard, *): 네임스페이스 임포트
// ---------------------------------------------------------
// math.js에서 여러 개의 함수(add, sub, multiply, divide)를 export 할 때
import * as MathTools from './math.js';

console.log(MathTools.add(5, 3));      // 8
console.log(MathTools.multiply(4, 2)); // 8


// ---------------------------------------------------------
// 3. 배럴(Barrel) 패턴: 입구 전용 파일(index.js) 만들기
// ---------------------------------------------------------
// [./utils/index.js] - 여러 모듈을 모아서 한 번에 내보내는 환승역
// export { add } from './math.js';
// export { log } from './logger.js';

// [app.js] - 마트에서 쇼핑하듯 한 줄로 가져오기
import { add, log } from './utils/index.js';

log(add(10, 20)); // 30


// ---------------------------------------------------------
// 4. Named & Default Export 동시 사용 및 Import 규칙
// ---------------------------------------------------------
// service.js -> export const apiVersion = "v2.0"; (Named)
// service.js -> export default function connect() { ... } (Default)

// 규칙: Default를 맨 앞에, Named는 중괄호 안에 작성
import connect, { apiVersion } from './service.js';

console.log(`현재 API 버전: ${apiVersion}`);
connect();


// ---------------------------------------------------------
// 5. [종합 실습] 레고 블록 조립 시스템 완성
// ---------------------------------------------------------

/* [Step 1: config.js] */
// export const DB_HOST = "localhost";
// export const DB_PORT = 5432;

/* [Step 2: util.js] */
// export default function sayWelcome(user) {
//     console.log(`어서오세요, ${user}님! 시스템에 접속하셨습니다.`);
// }

/* [Step 3: main.js - 부품 조립] */
import welcomeFunc from './util.js';             // Default 임포트
import * as Configs from './config.js';         // 전체 객체 임포트
import { DB_PORT as port } from './config.js';  // 별칭 사용 임포트

welcomeFunc("홍길동"); 
console.log(`기본 호스트 정보: ${Configs.DB_HOST}`);
console.log(`연결 포트 정보: ${port}`);


/**
 * [정리]
 * 1. as: 이름이 겹칠 때 가명을 붙여 충돌을 피함
 * 2. *: 모든 기능을 하나의 객체 덩어리로 가져옴
 * 3. Barrel: index.js를 통해 폴더 단위의 모듈 관리 용이성 증대
 * 4. Default & Named: 한 파일에 두 방식을 섞어 쓰는 실무적 패턴
 */