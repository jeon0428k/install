import { watch, access, writeFile, unlink, rename, appendFile, open } from 'node:fs/promises';
import { Buffer } from 'node:buffer'; 

const COMMAND_FILE = './file-commands.txt'; // 감시할 중앙 제어 파일 이름

// ==========================================
// 1. 유틸리티: 파일 존재 여부 및 권한 확인 (레이스 컨디션 방지)
// ==========================================
const fileExists = async (path) => {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
};

// ==========================================
// 2. 파일 제어 함수들 (Action Handlers)
// ==========================================

// ① 파일 생성
const createFile = async (path) => {
  if (await fileExists(path)) {
    return console.log(`👉 파일 '${path}'(이)가 이미 존재합니다.`);
  }
  try {
    await writeFile(path, ''); // 0바이트 빈 파일 생성
    console.log(`✅ 새 파일 '${path}'(이)가 성공적으로 생성되었습니다.`);
  } catch (e) {
    console.error(`❌ 파일 생성 중 오류 발생: ${e.message}`);
  }
};

// ② 파일 삭제 (Unlink)
const deleteFile = async (path) => {
  try {
    await unlink(path);
    console.log(`🗑️ 파일 '${path}'(이)가 성공적으로 삭제되었습니다.`);
  } catch (e) {
    if (e.code === 'ENOENT') {
      console.log(`⚠️ 삭제할 파일 '${path}'(이)가 존재하지 않습니다.`);
    } else {
      console.error(`❌ 파일 삭제 중 오류 발생: ${e.message}`);
    }
  }
};

// ③ 파일 이름 변경 및 이동
const renameFile = async (oldPath, newPath) => {
  try {
    await rename(oldPath, newPath);
    console.log(`✏️ 파일 이름이 '${newPath}'(으)로 성공적으로 변경되었습니다.`);
  } catch (e) {
    if (e.code === 'ENOENT') {
      console.log(`⚠️ 이름을 변경할 파일 '${oldPath}'(이)가 없거나 대상 경로가 잘못되었습니다.`);
    } else {
      console.error(`❌ 파일 이름 변경 중 오류 발생: ${e.message}`);
    }
  }
};

// ④ 파일 내용 추가 (디바운싱 적용)
let previousContent = ''; // 중복 실행(이벤트 바운스) 방지용 상태 변수

const addToFile = async (path, content) => {
  if (previousContent === content) return; // 동일한 내용이 연속으로 오면 무시

  try {
    await appendFile(path, content);
    previousContent = content;
    console.log(`📝 내용이 '${path}'에 성공적으로 추가되었습니다.`);
  } catch (e) {
    console.error(`❌ 파일에 내용 추가 중 오류 발생: ${e.message}`);
  }
};

// ==========================================
// 3. 명령어 해석기 (Command Parser)
// ==========================================
const executeCommand = async (commandString) => {
  const command = commandString.trim(); // 앞뒤 숨겨진 공백/줄바꿈 제거
  if (!command) return;

  // 1. 파일 생성 처리
  if (command.startsWith('create a file ')) {
    await createFile(command.replace('create a file ', '').trim());
  } 
  // 2. 파일 삭제 처리
  else if (command.startsWith('delete the file ')) {
    await deleteFile(command.replace('delete the file ', '').trim());
  } 
  // 3. 파일 이름 변경 처리 (정규표현식 캡처 그룹 활용)
  else if (command.startsWith('rename the file ')) {
    const match = command.match(/^rename the file (.+) to (.+)$/);
    if (match) {
      await renameFile(match[1].trim(), match[2].trim());
    } else {
      console.log('⚠️ 잘못된 파일 이름 변경 명령어 형식입니다.');
    }
  } 
  // 4. 파일 내용 추가 처리 (멀티라인 /s 플래그 활용)
  else if (command.startsWith('add to the file ')) {
    const match = command.match(/^add to the file (.+) this content: (.*)$/s);
    if (match) {
      await addToFile(match[1].trim(), match[2]);
    } else {
      console.log('⚠️ 잘못된 내용 추가 명령어 형식입니다.');
    }
  } else {
    console.log('❓ 알 수 없는 명령어입니다.');
  }
};

// ==========================================
// 4. 메인 실행부 (Watcher & Buffer Reader)
// ==========================================

// 감시할 파일이 없다면 미리 생성 (Top-Level Await 지원)
if (!(await fileExists(COMMAND_FILE))) {
  await writeFile(COMMAND_FILE, '');
}

console.log(`👀 ${COMMAND_FILE} 파일의 변경 사항을 감시하는 중... (종료하려면 Ctrl+C)`);

try {
  const watcher = watch(COMMAND_FILE);
  
  // 비동기 반복자를 이용한 우아한 이벤트 대기
  for await (const event of watcher) {
    if (event.eventType === 'change') { // EventEmitter가 쏘아올린 'change' 이벤트 필터링
      
      // 'r' 플래그로 파일 디스크립터(티켓) 발급
      const fileHandler = await open(COMMAND_FILE, 'r');
      
      try {
        const stat = await fileHandler.stat();
        const size = stat.size;

        if (size === 0) continue; // 파일 내용이 비워졌을 때는 무시

        // V8 엔진 외부의 C++ 메모리(버퍼) 할당 및 초기화
        const buff = Buffer.alloc(size);
        const offset = 0;
        const length = buff.byteLength;
        const position = 0;

        // 디스크의 이진 데이터를 버퍼로 쏟아붓기
        await fileHandler.read(buff, offset, length, position);

        // 16진수 버퍼 데이터를 UTF-8 문자열로 해독하여 파서로 전달
        const commandString = buff.toString('utf-8');
        await executeCommand(commandString);

      } finally {
        // 어떤 상황에서도 반드시 티켓(파일 디스크립터)을 반납하여 메모리 누수(EMFILE) 방지
        await fileHandler.close();
      }
    }
  }
} catch (e) {
  console.error(`❌ 감시자(Watcher) 오류 발생: ${e.message}`);
}