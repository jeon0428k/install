/**
 * ========================================================================
 * [12강 실습: HTTP 모듈을 활용한 라우팅 및 API 서버 구축]
 * ========================================================================
 * * [실행 방법]
 * 1. 이 코드를 'http_server.js'라는 이름으로 저장합니다.
 * 2. 터미널(CMD/PowerShell)을 열고 해당 폴더로 이동합니다.
 * 3. 'node http_server.js' 명령어를 입력하여 실행합니다.
 * * * [테스트 방법]
 * 1. 웹 브라우저를 열고 주소창에 'http://localhost:3000'을 입력하여 메인 페이지를 확인합니다.
 * 2. 주소창에 'http://localhost:3000/api/courses'를 입력하여 JSON 데이터 응답을 확인합니다.
 * 3. 존재하지 않는 주소(예: /hello)를 입력하여 404 에러 처리가 되는지 확인합니다.
 * * * [핵심 동작 원리]
 * - request (req): 클라이언트가 보낸 편지 (URL, 데이터 등 요청 정보)
 * - response (res): 서버가 보낼 답장 (상태 코드, 실제 데이터 등 응답 정보)
 * - Routing: request.url에 따라 다른 답장을 보내는 분기 처리 작업
 * ========================================================================
 */

// 1. 최신 표준 규칙에 따라 node: 접두사를 붙여 내장 모듈을 import 합니다.
import http from 'node:http';

/**
 * 2. 웹 서버 객체 생성
 * http.createServer()는 누군가 접속할 때마다 실행될 콜백 함수를 인자로 받습니다.
 * 이 안에서 우리는 '요청(req)'을 해석하고 '응답(res)'을 작성합니다.
 */
const server = http.createServer((request, response) => {

    // 사용자가 어떤 주소로 들어왔는지 파악합니다. (라우팅의 핵심)
    const url = request.url;

    // 1. 메인 홈페이지 요청 처리 ('/' 경로)
    if (url === '/') {
        /**
         * writeHead(상태코드, 헤더객체): 
         * 편지 봉투에 "성공(200)" 도장을 찍고, 
         * "이 내용은 일반 텍스트(text/plain)이며 한글(utf-8)이다"라고 명시합니다.
         */
        response.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.write('Hello World! 12강 HTTP 서버에 오신 것을 환영합니다.');
        
        // response.end(): 응답이 끝났음을 반드시 알려야 브라우저 로딩이 멈춥니다.
        response.end();
    }

    // 2. API 데이터 요청 처리 ('/api/courses' 경로)
    else if (url === '/api/courses') {
        // 데이터베이스에서 가져온 복잡한 정보라고 가정합니다.
        const courses = [
            { id: 1, title: 'Node.js 기초' },
            { id: 2, title: 'ESM 모듈 활용법' },
            { id: 3, title: 'HTTP 웹 서버 구축' }
        ];

        // 편지 봉투에 "이 안에는 데이터(application/json)가 들어있다"라고 알립니다.
        response.writeHead(200, { 'Content-Type': 'application/json' });

        /**
         * JSON.stringify(): 
         * 자바스크립트 객체/배열은 인터넷 선을 타고 직접 갈 수 없습니다.
         * 그래서 전 세계 공통 약속인 '문자열(JSON)' 형태로 쫙 펴서 변환해 보냅니다.
         */
        response.write(JSON.stringify(courses));
        response.end();
    }

    // 3. 그 외의 잘못된 경로 처리 (404 Not Found)
    else {
        response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.write('죄송합니다. 요청하신 페이지를 찾을 수 없습니다. (404 Error)');
        response.end();
    }
});

/**
 * 3. 서버 대기 (listen)
 * 서버를 3000번 포트(호실)에서 24시간 대기 모드로 만듭니다.
 * localhost:3000으로 접속하면 이 프로그램이 응답하게 됩니다.
 */
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`==========================================`);
    console.log(`🚀 12강 라우팅 서버가 가동 중입니다!`);
    console.log(`🌐 접속 주소: http://localhost:${PORT}`);
    console.log(`==========================================`);
});