// 원자로 메인 모듈 (하이브리드 내보내기)
export const MAX_TEMP = 10000;

export default function igniteCore() {
    console.log("🔥 [원자로] 핵융합 반응 시작! 정거장 전체에 동력이 공급됩니다.");
}