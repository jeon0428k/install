// 중앙 통제실 (최종 조립)
import igniteCore, { MAX_TEMP as CRITICAL_CORE_TEMP } from './reactor.js';
import * as StationSystems from './modules/index.js';

console.log(`[로그] 중앙 제어 시스템 부팅... (임계 온도: ${CRITICAL_CORE_TEMP}도)`);

igniteCore();
StationSystems.getPowerLevel();
StationSystems.routePower();
StationSystems.scanSector();

console.log("✅ [완료] 갤럭시 넥서스 모든 시스템이 정상 가동 중입니다.");