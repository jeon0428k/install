/**
 * [Node.js Buffer Section Master Class - Final Compilation]
 * Instructor: Mike
 * Topic: From Binary Basics to System Architecture
 * * 이 코드는 25강부터 30강까지의 모든 하드웨어 및 소프트웨어 원리를 담고 있습니다.
 */

import { Buffer, constants } from 'node:buffer';

// =================================================================
// [25-26강] 메모리 할당과 하드웨어적 실체
// =================================================================
console.log("--- 1. RAM 할당 및 하드웨어 보안 (Mike's Engineering View) ---");

// Buffer.alloc은 OS 커널에 '시스템 콜'을 보내 물리 RAM의 트랜지스터 공간을 예약합니다.
// Zero-fill: 이전 사용자의 데이터 흔적을 0으로 지워 보안 사고를 방지합니다.
const physicalMem = Buffer.alloc(8); 

// MAX_LENGTH: 32비트 주소 체계의 유산으로 단일 버퍼는 보통 2GB~4GB로 제한됩니다.
console.log(`단일 버퍼 할당 상한선: ${(constants.MAX_LENGTH / 1024 / 1024 / 1024).toFixed(2)} GB`);

/**
 * [2의 보수(Two's Complement)]
 * 컴퓨터는 뺄셈 회로가 없어 덧셈만으로 음수를 처리합니다.
 * -42 저장: 양수(00101010) -> 반전(11010101) -> +1(11010110)
 */
physicalMem.writeInt8(-42, 0); // 오프셋 0 위치에 부호 있는 8비트 정수 기록
console.log("2의 보수 복원 결과:", physicalMem.readInt8(0)); // -42
console.log("");


// =================================================================
// [27강] 데이터 직렬화와 복원 (Serialization)
// =================================================================
console.log("--- 2. 데이터 직렬화 및 URL 인코딩 원리 ---");

// [코드 포인트 vs 인코딩]: 글자의 고유 번호와 이를 메모리에 찍는 물리적 규칙(UTF-8 등)
// URL 인코딩: 아스키만 이해하는 구형 장비를 위해 한글을 16진수로 쪼개 퍼센트(%)를 붙임
const hexQuery = "eb85b8eb939ceca09cec9db4ec9790ec8aa4"; // '노드제이에스'
const decodedFromNetwork = Buffer.from(hexQuery, "hex");

console.log("네트워크 데이터 복원:", decodedFromNetwork.toString("utf-8")); // 노드제이에스
console.log("");


// =================================================================
// [28-29강] 성능 최적화 전략: Pooling & Unsafe
// =================================================================
console.log("--- 3. 성능 최적화: 버퍼 풀링(Pooling) ---");

/**
 * [Buffer Pooling]
 * Node.js는 실행 시 8KB(8192B) 수영장을 미리 빌려둡니다.
 * allocUnsafe는 시스템 콜 없이 이 풀에서 메모리를 쓱 잘라 즉시 반환하여 '광속'을 냅니다.
 * 단, 0으로 지우지 않으므로 '보안 리스크'가 있어 반드시 새로운 데이터로 덮어씌워야 합니다.
 */
const fastBuffer = Buffer.allocUnsafe(2048); 

// [비트 연산] poolSize >>> 1 : CPU 회로를 직접 밀어 숫자를 2로 나누는 가장 빠른 방법
const poolThreshold = Buffer.poolSize >>> 1; 
console.log(`풀링 적용 기준(4KB): ${poolThreshold} bytes`);

// [allocUnsafeSlow]: 수명이 매우 긴 데이터는 공용 풀을 오염시키지 않도록 독립 할당하여 '메모리 파편화' 방지
const longLivedData = Buffer.allocUnsafeSlow(256);
console.log("");


// =================================================================
// [30강] 시스템 아키텍처로의 확장
// =================================================================
console.log("--- 4. 최종 아키텍처: 스트림과 비동기 I/O 예고 ---");

/**
 * [Mike's Final Summary]
 * 1. OOM 크래시: 5GB 파일을 통째로 alloc 하려 하면 서버는 즉사합니다.
 * 2. 스트림(Stream): 데이터를 '청크(Chunk)' 단위로 쪼개어 메모리 수압(Backpressure)을 조절하며 흐르게 합니다.
 * 3. DMA(Direct Memory Access): CPU 대신 전담 칩셋이 데이터를 RAM으로 퍼나르는 하드웨어 기술입니다.
 * 4. 비동기 I/O: 느린 디스크 읽기를 OS에 맡기고, 요리사(이벤트 루프)는 다음 주문을 받는 효율의 극치입니다.
 */

try {
    const hugeTaskSize = 5 * 1024 * 1024 * 1024; // 5GB
    console.log(`${hugeTaskSize}바이트 처리를 위해선 '스트림' 파이프라인 설계가 필수입니다.`);
} catch (e) {
    console.error("잘못된 설계는 서버를 비명 지르게 합니다.");
}

console.log("\n버퍼 섹션 종료. 다음은 파일 시스템(FS)과 비동기 I/O의 세계로 나아갑니다.");