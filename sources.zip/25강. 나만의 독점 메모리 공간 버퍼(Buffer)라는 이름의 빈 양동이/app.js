/**
 * [강의 실습 통합본] Node.js Buffer: 메모리 할당부터 로우 레벨 조작까지
 * 실행 방법: node buffer_study.js
 */

// --- Step 1 & 3: 메모리 할당과 초기화 (Allocation & Initialization) ---
console.log("--- 1. 메모리 할당 및 초기화 ---");
// 운영체제에게 4바이트(배터리 32개)의 독점 공간을 요청합니다.
const myBuffer = Buffer.alloc(4); 

console.log("할당된 버퍼 (16진수):", myBuffer); 
// 출력: <Buffer 00 00 00 00> -> 보안을 위해 0으로 'Zero-fill'된 상태
console.log("");


// --- Step 3: 1바이트 철칙과 랩어라운드 (Wraparound) ---
console.log("--- 2. 1바이트 철칙 테스트 ---");
const logicBuffer = Buffer.alloc(2);

// 첫 번째 칸(0번 인덱스)에 1바이트 최대치인 255(ff)를 넣습니다.
logicBuffer[0] = 255; 

// 두 번째 칸(1번 인덱스)에 256을 넣으면 어떻게 될까요?
// 8비트 한계를 넘어가므로 주행거리계처럼 다시 0으로 돌아갑니다.
logicBuffer[1] = 256; 

console.log("255와 256 주입 결과:", logicBuffer); 
// 출력: <Buffer ff 00>
console.log("");


// --- Step 4: 크기 불변의 법칙과 디스카드 (Discard) ---
console.log("--- 3. 크기 불변 및 디스카드 테스트 ---");
const fixedBuffer = Buffer.alloc(4); // 4바이트짜리 '절대 변하지 않는' 쇠상자

// "안녕" (한글은 글자당 3바이트, 총 6바이트 필요)을 억지로 우겨넣습니다.
fixedBuffer.write("안녕");

console.log("4바이트 버퍼에 '안녕' 기록 시:");
console.log("Hex 데이터:", fixedBuffer); 
console.log("문자열 변환:", fixedBuffer.toString()); 
// 출력: "안"과 깨진 글자 -> 4바이트를 넘긴 데이터는 가차 없이 버려짐(Discard)
console.log("");


// --- Step 6: 로우 레벨 데이터 수술 (Low-Level Surgery) ---
console.log("--- 4. 로우 레벨 데이터 조작 ---");
const myData = Buffer.from("Buffer");

console.log("수술 전:", myData.toString()); // "Buffer"

// 버퍼의 0번 인덱스('B'의 아스키코드 66)를 's'(아스키코드 115)로 직접 교체합니다.
myData[0] = 115;

console.log("수술 후 (B -> s):", myData.toString()); // "suffer"
console.log("");


// --- Step 7: 물리적 한계와 OOM(Out of Memory) 개념 ---
console.log("--- 5. 메모리 한계 확인 ---");
console.log(`현재 이 버퍼의 최대 할당 가능 크기: ${Buffer.constants.MAX_LENGTH.toLocaleString()} bytes`);
// 이 수치를 넘겨서 할당하려고 하면 프로그램은 즉시 크래시(Crash)가 발생합니다.