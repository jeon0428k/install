import { watch, access, writeFile, unlink, rename, appendFile, open, stat } from 'node:fs/promises';
import { Buffer } from 'node:buffer';

const COMMAND_FILE = './file-commands.txt'; // 감시할 중앙 제어 파일

// ==========================================
// 1. 유틸리티: 파일 존재 여부 확인
// ==========================================
const fileExists = async (path) => {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
};

// ==========================================
// 🌟 [최적화 핵심 1] 작업 대기열 (Task Queue) 클래스 도입
// ==========================================
class CommandQueue {
  constructor() {
    this.queue = [];           // 명령어를 줄 세울 대기열(배열)
    this.isProcessing = false; // 현재 은행 창구 직원이 일하고 있는지(Lock) 상태 확인
  }

  // 대기열에 새로운 작업을 밀어 넣는 함수 (번호표 발급)
  enqueue(task) {
    this.queue.push(task);
    this.processNext(); // 작업이 추가되면 즉시 창구 직원을 호출
  }

  // 대기열의 작업을 순서대로 하나씩 꺼내서 처리하는 함수 (FIFO)
  async processNext() {
    // 직원이 이미 일하고 있거나, 대기열이 비어있다면 그냥 돌아감 (비동기 충돌 방지)
    if (this.isProcessing || this.queue.length === 0) return;

    this.isProcessing = true; // 직원 업무 시작! (문 걸어 잠금 - Lock)
    const task = this.queue.shift(); // 대기열 맨 앞의 작업을 꺼냄

    try {
      await task(); // 작업 실행 (파일 생성, 삭제 등)
    } catch (error) {
      console.error("❌ 큐 작업 처리 중 에러:", error);
    }

    this.isProcessing = false; // 직원 업무 끝! (문 열림 - Unlock)
    this.processNext(); // 대기열에 남은 다음 손님이 있는지 다시 확인
  }
}

// 전역 큐 인스턴스 생성
const commandQueue = new CommandQueue();

// ==========================================
// 2. 파일 제어 함수들 (Action Handlers)
// ==========================================

// ① 파일 생성
const createFile = async (path) => {
  if (await fileExists(path)) {
    return console.log(`👉 파일 '${path}'(이)가 이미 존재합니다.`);
  }
  try {
    await writeFile(path, '');
    console.log(`✅ 새 파일 '${path}'(이)가 성공적으로 생성되었습니다.`);
  } catch (e) {
    console.error(`❌ 파일 생성 중 오류 발생: ${e.message}`);
  }
};

// ② 파일 삭제
const deleteFile = async (path) => {
  try {
    await unlink(path);
    console.log(`🗑️ 파일 '${path}'(이)가 성공적으로 삭제되었습니다.`);
  } catch (e) {
    if (e.code === 'ENOENT') console.log(`⚠️ 삭제할 파일 '${path}'(이)가 존재하지 않습니다.`);
    else console.error(`❌ 파일 삭제 중 오류 발생: ${e.message}`);
  }
};

// ③ 파일 이름 변경
const renameFile = async (oldPath, newPath) => {
  try {
    await rename(oldPath, newPath);
    console.log(`✏️ 파일 이름이 '${newPath}'(으)로 성공적으로 변경되었습니다.`);
  } catch (e) {
    if (e.code === 'ENOENT') console.log(`⚠️ 원본 파일 '${oldPath}'(이)가 없습니다.`);
    else console.error(`❌ 파일 이름 변경 중 오류 발생: ${e.message}`);
  }
};

// ④ 파일 내용 추가
const addToFile = async (path, content) => {
  try {
    await appendFile(path, content + '\n');
    console.log(`📝 내용이 '${path}'에 성공적으로 추가되었습니다.`);
  } catch (e) {
    console.error(`❌ 파일에 내용 추가 중 오류 발생: ${e.message}`);
  }
};

// ==========================================
// 3. 명령어 해석기 (Command Parser)
// ==========================================
const executeCommand = async (commandString) => {
  // 전체 텍스트를 줄바꿈 기준으로 분리하여 다중 명령어를 각각 처리
  const commands = commandString.split('\n').map(cmd => cmd.trim()).filter(cmd => cmd);

  for (const command of commands) {
    if (command.startsWith('create a file ')) {
      const path = command.replace('create a file ', '').trim();
      commandQueue.enqueue(() => createFile(path));
    }
    else if (command.startsWith('delete the file ')) {
      const path = command.replace('delete the file ', '').trim();
      commandQueue.enqueue(() => deleteFile(path));
    }
    else if (command.startsWith('rename the file ')) {
      const match = command.match(/^rename the file (.+) to (.+)$/);
      if (match) commandQueue.enqueue(() => renameFile(match[1].trim(), match[2].trim()));
      else console.log('⚠️ 잘못된 파일 이름 변경 형식입니다.');
    }
    else if (command.startsWith('add to the file ')) {
      const match = command.match(/^add to the file (.+) this content: (.*)$/);
      if (match) commandQueue.enqueue(() => addToFile(match[1].trim(), match[2]));
      else console.log('⚠️ 잘못된 내용 추가 형식입니다.');
    }
    else {
      console.log(`❓ 알 수 없는 명령어입니다: ${command}`);
    }
  }
};

// ==========================================
// 4. 메인 실행부 (Watcher & Buffer Reader)
// ==========================================

// 🌟 [최적화 핵심 3] 어디까지 읽었는지 기억하는 '오프셋(커서) 추적 변수'
let lastReadOffset = 0;

if (!(await fileExists(COMMAND_FILE))) {
  await writeFile(COMMAND_FILE, '');
} else {
  // 서버가 켜질 때, 기존 파일에 있던 과거 명령어는 이미 처리된 것으로 간주하고 건너뜀
  const initialStat = await stat(COMMAND_FILE);
  lastReadOffset = initialStat.size;
}

console.log(`👀 ${COMMAND_FILE} 파일 감시 중... (실무 최적화 모드 가동)`);

try {
  const watcher = watch(COMMAND_FILE);

  // 🌟 [최적화 핵심 2] 감시자(Watcher) 레벨의 디바운싱 타이머 변수
  let watchTimeout = null;

  for await (const event of watcher) {
    if (event.eventType === 'change') {

      // OS 이벤트 폭주 방지 (디바운싱)
      clearTimeout(watchTimeout);

      watchTimeout = setTimeout(async () => {
        const fileHandler = await open(COMMAND_FILE, 'r');
        try {
          const fileStat = await fileHandler.stat();
          
          // 파일 크기가 그대로면 새로 추가된 내용이 없음
          if (fileStat.size === lastReadOffset) return; 

          // 사용자가 에디터에서 내용을 통째로 지우거나 수정해서 크기가 줄어든 경우 (초기화 대응)
          if (fileStat.size < lastReadOffset) {
            lastReadOffset = fileStat.size; 
            return;
          }

          // 🌟 마지막으로 읽었던 위치부터, 새로 늘어난 바이트 크기만큼만 정확히 계산해서 읽어오기
          const bytesToRead = fileStat.size - lastReadOffset;
          const buff = Buffer.alloc(bytesToRead);
          
          await fileHandler.read(buff, 0, bytesToRead, lastReadOffset);
          
          // 다음 번 읽기를 위해 커서(오프셋) 위치 업데이트
          lastReadOffset = fileStat.size;

          const commandString = buff.toString('utf-8');
          await executeCommand(commandString);

        } finally {
          await fileHandler.close();
        }
      }, 100);
    }
  }
} catch (e) {
  console.error(`❌ 감시자 오류: ${e.message}`);
}