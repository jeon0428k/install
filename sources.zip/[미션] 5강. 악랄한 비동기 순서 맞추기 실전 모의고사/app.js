// [난이도: 하] 문제 1. 다음 코드의 출력 순서를 맞춰보세요.
console.log('1. 현장 출근');

setTimeout(() => console.log('2. 자재 주문 (Timer)'), 0);

Promise.resolve().then(() => console.log('3. 인부 출근부 (VIP)'));

process.nextTick(() => console.log('4. 긴급 안전 점검 (VVIP)'));

console.log('5. 현장 퇴근');


// [난이도: 중] 문제 2. 다음 코드의 출력 순서를 맞춰보세요.
setTimeout(() => {
    console.log('A (첫 번째 알람)');
    process.nextTick(() => console.log('B (기습 VVIP 접수)'));
    Promise.resolve().then(() => console.log('C (기습 VIP 접수)'));
}, 0);

setTimeout(() => console.log('D (두 번째 알람)'), 0);


// [난이도: 상] 문제 3. 다음 코드의 출력 순서를 추적해보세요.
console.log('시작');

setTimeout(() => {
    console.log('타이머 1');
    Promise.resolve().then(() => console.log('프로미스 1'));
}, 0);

process.nextTick(() => {
    console.log('틱 1');
    setTimeout(() => console.log('타이머 2'), 0);
});

Promise.resolve().then(() => {
    console.log('프로미스 2');
    process.nextTick(() => console.log('틱 2'));
});

console.log('종료');