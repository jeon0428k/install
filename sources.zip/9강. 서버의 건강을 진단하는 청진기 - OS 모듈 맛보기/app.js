/**
 * ========================================================================
 * [9강: 서버의 건강을 진단하는 청진기 - OS 모듈 활용]
 * ========================================================================
 * * 1. OS 모듈의 목적
 * - 서버 컴퓨터(운영체제)의 상태를 실시간으로 모니터링
 * - CPU 사용량, 메모리 잔량 등을 파악하여 서버 다운을 미리 방지
 * * 2. 주요 개념
 * - CPU 코어: 실제 계산을 수행하는 '일꾼'
 * - 메모리(RAM): 데이터를 펼쳐놓고 작업하는 '책상'
 */

import os from 'node:os';

// --- [PART 1: 시스템 기본 정보 진단] ---
console.log("--- [시스템 기본 정보] ---");
console.log(`운영체제 종류: ${os.type()}`);       // 예: Windows_NT, Darwin, Linux
console.log(`운영체제 버전: ${os.release()}`);    // 상세 버전 정보
console.log(`시스템 가동 시간: ${os.uptime()}초`); // 부팅 후 흐른 시간
console.log("--------------------------\n");

// -------------------------------------------------------------------------
// --- [PART 2: 하드웨어 자원(체력) 진단] ---
// 1. CPU 정보 (두뇌와 일꾼 수)
const cpus = os.cpus();
console.log(`CPU 코어 개수: ${cpus.length}개`);
console.log(`메인 CPU 모델: ${cpus[0].model}`);

// 2. 메모리 정보 (작업 공간)
const totalMemory = os.totalmem(); // 전체 용량 (Byte)
const freeMemory = os.freemem();   // 여유 용량 (Byte)

/**
 * 💡 단위 변환 공식 (Byte -> GB)
 * 1024 Byte = 1 KB
 * 1024 KB   = 1 MB
 * 1024 MB   = 1 GB
 * 즉, 1024로 세 번 나누면 GB 단위가 됩니다.
 */
const totalGB = (totalMemory / 1024 / 1024 / 1024).toFixed(2);
const freeGB = (freeMemory / 1024 / 1024 / 1024).toFixed(2);
const usedPercentage = (((totalMemory - freeMemory) / totalMemory) * 100).toFixed(1);

console.log(`전체 메모리: ${totalGB} GB`);
console.log(`여유 메모리: ${freeGB} GB`);
console.log(`현재 메모리 사용률: ${usedPercentage}%`);
console.log("--------------------------");

/**
 * [실습 포인트]
 * - os.cpus().length: 나중에 멀티 프로세싱(Worker Threads 등)을 구현할 때 
 * 동시에 돌릴 작업의 개수를 결정하는 기준이 됩니다.
 * - os.freemem(): 여유 메모리가 너무 적다면 서버가 멈출 위험이 있으므로 
 * 모니터링 알람 시스템을 구축할 때 핵심 지표로 쓰입니다.
 */