/**
 * ========================================================================
 * [Node.js 시스템 시뮬레이터: IIFE 도구 주입의 모든 것]
 * ========================================================================
 * * 1. 실행 전 준비사항 (파일 구성):
 * - 같은 폴더에 'index.js' 파일을 만들고 아래 내용을 작성하세요.
 * ---------------------------------------------------------
 * console.log("▶ index.js가 실행되었습니다!");
 * console.log("- 주입된 경로: ", __filename);
 * module.exports = { data: "성공!" };
 * ---------------------------------------------------------
 * * 2. 실행 방법:
 * - 터미널에서 'node engine.js' 명령어를 입력합니다.
 * * 3. 작동 원리 (Workflow):
 * (1) 코드 로드: 시스템이 index.js를 단순 텍스트로 읽어옴
 * (2) 래핑(Wrapping): 읽어온 텍스트 앞뒤에 IIFE 함수 코드를 문자열로 결합
 * (3) 함수화: 문자열 상태의 코드를 실제 실행 가능한 Function 객체로 변환
 * (4) 주입 및 실행: 미리 준비한 도구들(require, module 등)을 파라미터로 전달
 */

const fs = require('fs');
const path = require('path');

// --- [STEP 1] 모듈 실행을 위한 '가짜 도구 상자' 준비 ---
// 실제 Node.js도 파일마다 이런 객체들을 백그라운드에서 생성합니다.
const mockModule = { exports: {} };
const mockRequire = (name) => `[${name} 모듈] (시스템이 주입한 require로 불러옴)`;
const mockFilename = path.join(__dirname, 'index.js');
const mockDirname = __dirname;

try {
    // --- [STEP 2] 사용자 코드 읽기 (index.js) ---
    // 개발자가 짠 코드는 아직까지는 그저 '긴 글자'일 뿐입니다.
    const userCode = fs.readFileSync(mockFilename, 'utf8');

    // --- [STEP 3] IIFE 껍데기 씌우기 (비밀스러운 주입 과정) ---
    // Node.js는 내부적으로 아래와 같이 함수 머리(Header)와 꼬리(Footer)를 붙입니다.
    const wrapper = [
        '(function (exports, require, module, __filename, __dirname) {\n',
        userCode,
        '\n});'
    ].join('');

    console.log("--- [시스템] 래핑된 최종 코드 형태 ---");
    console.log(wrapper);
    console.log("--------------------------------------\n");

    // --- [STEP 4] 문자열을 함수로 변환 ---
    // new Function(인자들..., 함수본문)을 사용하여 실행 가능한 형태로 만듭니다.
    const compiledWrapper = new Function(
        'exports', 
        'require', 
        'module', 
        '__filename', 
        '__dirname', 
        userCode // 여기에 우리가 짠 코드가 본문으로 들어갑니다.
    );

    // --- [STEP 5] 실행 및 도구 주입 ---
    // 함수를 호출하면서 준비했던 도구들을 인자로 쏙 넣어줍니다.
    // 이때 비로소 index.js 내부에서 __filename, require 등을 사용할 수 있게 됩니다.
    compiledWrapper(
        mockModule.exports, 
        mockRequire, 
        mockModule, 
        mockFilename, 
        mockDirname
    );

    // --- [STEP 6] 결과 확인 ---
    // index.js에서 module.exports에 담은 내용이 시스템 객체에 저장되었는지 확인합니다.
    console.log("\n--- [시스템] 실행 완료 후 추출된 module.exports ---");
    console.log(mockModule.exports);

} catch (err) {
    console.error("오류 발생: index.js 파일이 같은 폴더에 있는지 확인하세요!");
}

/**
 * [최종 요약]
 * 우리가 index.js에서 아무 설정 없이 require를 쓸 수 있는 이유는,
 * Node.js 시스템이 위와 같이 코드를 함수로 감싸고 
 * 실행 시점에 도구들을 '인자(Arguments)'로 넘겨주기 때문입니다.
 */