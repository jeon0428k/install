// [1. IIFE 원리]
(function() {
    let myVariable = "안전한 지역 변수";
    console.log(myVariable);
})();

// ---------------------------

// [2. CommonJS 방식]
// a.js
module.exports.name = "mike";

// b.js
module.exports.age = 20;

// main.js
const moduleA = require('./a.js');
const moduleB = require('./b.js');
console.log(moduleA.name);
console.log(moduleB.age);

// ---------------------------

// [3. ESM 방식 - package.json 설정 필요]
// { "type": "module" }

// logger.js
const secretPassword = "비밀"; 

export function printMessage(message) {
    console.log(`[시스템 알림]: ${message}`);
}
export const version = "1.0.0";

export default function initializeLogger() {
    console.log("로거 시스템을 초기화합니다.");
}

// app.js
import initializeLogger, { printMessage, version } from './logger.js';

initializeLogger();
printMessage(`ESM 시스템 v${version} 작동 중`);

// ---------------------------

// [4. 최종 실습 미션]
// logger.js
export function log(message) {
    console.log(`로그 기록: ${message}`);
}

// app.js
import { log } from './logger.js';
log("Node.js의 모듈 시스템 실습 중입니다!");