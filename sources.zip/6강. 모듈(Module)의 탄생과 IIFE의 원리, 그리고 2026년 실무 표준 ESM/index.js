// index.js
// 주의: 여기에는 IIFE를 직접 쓸 필요가 없습니다. 시스템이 씌워줄 거니까요!

console.log("▶ index.js 실행 중...");
console.log("- 주입된 파일명:", __filename);

// 시스템이 넣어준 require 사용
const result = require('database');
console.log("- require 결과:", result);

// 시스템이 넣어준 module.exports에 데이터 저장
module.exports = {
    message: "성공적으로 내보내졌습니다!",
    date: new Date().toLocaleString()
};