/**
 * [Node.js Buffer 마스터 클래스: 공식 문서 핵심 메서드 & CS 아키텍처]
 * Instructor: Mike
 * 내용: 엔디언, 제로 카피, SIMD 가속, 메모리 스파이크 통제
 */

import { Buffer } from 'node:buffer';

// =================================================================
// 1. 엔디언(Endianness): CPU와 네트워크의 바이트 해석 차이
// =================================================================
console.log("--- 1. 엔디언(Endianness) 및 바이트 순서 ---");

const endianBuf = Buffer.allocUnsafe(4);

/**
 * [Mike's CS Note]
 * - Big-Endian (BE): 네트워크 통신 표준. 큰 자리수(0x12)부터 저장.
 * - Little-Endian (LE): 인텔/AMD CPU 표준. 산술 연산 최적화를 위해 작은 자리수(0x78)부터 저장.
 * IoT 기기 센서 데이터 파싱이나 C++ 서버 통신 시 이 순서가 틀리면 데이터가 오염됩니다.
 */
endianBuf.writeUInt32BE(0x12345678, 0);
console.log('Big-Endian (Network Standard):', endianBuf); // <Buffer 12 34 56 78>

endianBuf.writeUInt32LE(0x12345678, 0);
console.log('Little-Endian (x86 CPU Int): ', endianBuf); // <Buffer 78 56 34 12>
console.log("");


// =================================================================
// 2. Buffer.byteLength: 문자열 길이의 함정 (Truncation 방지)
// =================================================================
console.log("--- 2. 물리적 바이트 크기 측정 (byteLength) ---");

const myText = "안녕하세요 Mike";

/**
 * [Mike's CS Note]
 * - .length: 자바스크립트 엔진의 '글자 수' (10)
 * - byteLength: 실제 RAM의 '물리적 바이트 수' (22)
 * HTTP Content-Length 헤더에 .length를 쓰면 한글 뒷부분이 잘리는 'Truncation' 대참사가 발생합니다.
 */
const charLen = myText.length;
const byteLen = Buffer.byteLength(myText, "utf-8");

console.log(`글자 수: ${charLen}, 실제 점유 바이트: ${byteLen}`);
console.log("");


// =================================================================
// 3. subarray: Zero-copy 아키텍처의 핵심 (성능 최적화)
// =================================================================
console.log("--- 3. subarray (얕은 복사/Zero-copy) ---");

const giant = Buffer.from([1, 2, 3, 4, 5]);

/**
 * [Mike's CS Note]
 * - 원리: 데이터를 복제하지 않고 원본 메모리 주소(Pointer)만 가리키는 '뷰(View)' 생성.
 * - 장점: 10GB 파일 처리 시 메모리 복사 비용 0 (Zero-copy).
 * - 단점: 뷰를 수정하면 원본이 오염됨 (Shared Memory).
 */
const view = giant.subarray(1, 3); // 인덱스 1~2 구간 참조
view[0] = 99; // 뷰를 통해 원본 물리 메모리 값 수정

console.log('수정된 원본 버퍼:', giant); // [1, 99, 3, 4, 5]
console.log("");


// =================================================================
// 4. buf.copy: 안전한 영혼의 복제 (Race Condition 방지)
// =================================================================
console.log("--- 4. buf.copy (깊은 복사/Deep Copy) ---");

const source = Buffer.from([10, 20, 30]);
const target = Buffer.allocUnsafe(3);

/**
 * [Mike's CS Note]
 * - 원리: C언어의 memcpy를 호출하여 전자를 물리적으로 한 땀 한 땀 복제.
 * - 용도: 비동기 환경에서 스레드 간 데이터 경합(Race Condition)을 막기 위해 메모리 완전 분리.
 */
source.copy(target);
target[0] = 77; 

console.log('원본 보존 확인:', source); // [10, 20, 30] 유지
console.log('독립적 타겟:', target); // [77, 20, 30]
console.log("");


// =================================================================
// 5. 검색 및 비교: SIMD 하드웨어 가속
// =================================================================
console.log("--- 5. 이진 데이터 스캐닝 (SIMD 가속) ---");

const fileData = Buffer.from("Mike\nNodeJS\nBuffer");

/**
 * [Mike's CS Note]
 * - SIMD (Single Instruction, Multiple Data): CPU가 한 바이트씩 찾지 않고 수십 바이트를 병렬로 싹쓸이.
 * - 용도: 파일 시그니처(Magic Number) 검증이나 멀티파트 경계선 검색 시 광속의 성능 발휘.
 */
const lineBreak = fileData.indexOf(0x0a); // 줄바꿈(\n) 16진수 위치 스캔
console.log(`줄바꿈 기호 위치: ${lineBreak}`);
console.log("");


// =================================================================
// 6. Buffer.concat: 메모리 스파이크(Spike) 주의보
// =================================================================
console.log("--- 6. Buffer.concat (병합과 OOM 위험) ---");

const chunks = [Buffer.from("A"), Buffer.from("B"), Buffer.from("C")];

/**
 * [Mike's CS Note]
 * - 원리: 모든 조각의 크기를 합산 -> 새 메모리 할당 -> memcpy로 복사.
 * - 위험: 1GB 조각들을 합치면 순간적으로 2GB의 RAM이 필요함 (메모리 스파이크).
 * - 설계: 대용량 데이터는 합치지 말고 '스트림' 파이프라인으로 처리할 것.
 */
const final = Buffer.concat(chunks);
console.log('병합 결과:', final.toString());