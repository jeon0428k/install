/**
 * ========================================================================
 * [10강: 하드디스크와의 짜릿한 첫 만남 - File System (fs) 모듈]
 * ========================================================================
 * * 1. fs 모듈의 목적
 * - 파일 및 폴더 생성, 읽기, 수정, 삭제 (CRUD)
 * - 휘발성 메모리(RAM)의 한계를 넘어 데이터를 하드디스크에 영구 저장
 * * 2. 핵심 키워드
 * - Sandbox: 브라우저 내 자바스크립트가 시스템 파일에 접근 못 하게 막는 보안 구역
 * - Buffer: 이진 데이터(0, 1)가 잠시 머무는 임시 정거장
 * - UTF-8: 이진 데이터를 사람이 읽을 수 있는 문자로 바꿔주는 통역 사전
 */

import fs from 'node:fs';
import path from 'node:path';

// 현재 폴더 경로 및 파일 경로 설정
const currentFolder = import.meta.dirname;
const filePath = path.join(currentFolder, 'message.txt');

// --- [PART 1: 파일 쓰기 (Create/Update)] ---
// writeFileSync(경로, 내용): 동기 방식으로 파일을 생성하고 기록합니다.
const content = '안녕하세요! Node.js가 파일 시스템에 접근했습니다.';

try {
    fs.writeFileSync(filePath, content);
    console.log('✅ 파일이 성공적으로 생성되었습니다.');
} catch (err) {
    console.error('❌ 파일 생성 중 에러 발생:', err);
}

// -------------------------------------------------------------------------
// --- [PART 2: 파일 읽기 (Read)] ---
// readFileSync(경로, 인코딩): 인코딩('utf8')이 없으면 날것의 Buffer를 반환합니다.
try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    console.log(`📖 읽어온 파일 내용: ${fileContent}`);
} catch (err) {
    console.error('❌ 파일을 읽는 중 에러 발생:', err);
}

/**
 * [💡 다음 단계를 위한 복선]
 * - 현재 사용한 'Sync' 함수들은 작업이 끝날 때까지 서버를 멈춰 세웁니다 (동기 방식).
 * - 실무에서는 서버가 멈추지 않도록 '비동기(Async)' 방식을 주로 사용합니다.
 * - 11강에서는 Node.js의 심장박동인 '이벤트'를 통해 효율적인 흐름 제어를 배웁니다.
 */