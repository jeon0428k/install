/**
 * [Node.js 이벤트 루프 심화 실습 세트]
 * 실습 방법: 각 연습(Practice)의 주석을 하나씩 해제하여 실행 결과를 확인하세요.
 */

// -------------------------------------------------------------------------
// [Practice 01] 콜 스택과 블로킹 (동기 지연)
// -------------------------------------------------------------------------

console.log('--- Practice 01 시작 ---');
console.log('1. 가벼운 작업 처리');

// 100억 번 연산으로 스택 점유 (이벤트 루프 진입 차단)
for (let i = 0; i < 10000000000; i++) {} 

console.log('2. 무거운 연산 종료 후 출력 (이전까지 시스템 마비)');

// -------------------------------------------------------------------------
// [Practice 02] VIP 결재함 내부의 계급 분쟁 (nextTick vs Promise)
// -------------------------------------------------------------------------

console.log('--- Practice 02 시작 ---');

Promise.resolve().then(() => console.log('1. [VIP] Promise 실행'));
process.nextTick(() => console.log('2. [VVIP] nextTick 실행'));
Promise.resolve().then(() => console.log('3. [VIP] Promise 실행'));

// 예상 결과: 2 -> 1 -> 3

// -------------------------------------------------------------------------
// [Practice 03] 정거장 내에서의 아찔한 새치기 (Tick Level Microtask Check)
// -------------------------------------------------------------------------

console.log('--- Practice 03 시작 ---');

setTimeout(() => {
    console.log('1. 타이머 첫 번째 알람');
    Promise.resolve().then(() => console.log('2. [새치기] 알람 도중 생성된 VIP 서류'));
}, 0);

setTimeout(() => {
    console.log('3. 타이머 두 번째 알람');
}, 0);

// 예상 결과: 1 -> 2 -> 3

// -------------------------------------------------------------------------
// [Practice 04] 절대 권력의 부작용, 기아 현상 (Starvation)
// ⚠️ 주의: 실행 시 무한 루프 발생 (Ctrl + C로 종료)
// -------------------------------------------------------------------------

console.log('--- Practice 04 시작 ---');

setTimeout(() => console.log('실행되지 못하는 일반 알람'), 0);

function infiniteVVIP() {
    process.nextTick(() => {
        console.log('VVIP 서류 무한 생성 중...');
        infiniteVVIP();
    });
}

infiniteVVIP();

// -------------------------------------------------------------------------
// [Practice 05] 최종 보스: 모든 흐름의 결합
// -------------------------------------------------------------------------

console.log('--- Practice 05 시작 ---');

console.log('1. 현장 출근 (동기)');

setTimeout(() => console.log('6. 예약된 알람 (Timer)'), 0);

Promise.resolve().then(() => {
    console.log('4. VIP 긴급 서류 (Promise)');
    process.nextTick(() => console.log('5. [새치기] VIP 내부의 VVIP (nextTick)'));
});

process.nextTick(() => console.log('3. VVIP 절대 우선 서류 (nextTick)'));

console.log('2. 현장 퇴근 (동기)');

// 예상 결과: 1 -> 2 -> 3 -> 4 -> 5 -> 6
