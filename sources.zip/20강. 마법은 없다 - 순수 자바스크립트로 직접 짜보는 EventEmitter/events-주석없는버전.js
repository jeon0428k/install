// events.js
// 최신 자바스크립트 표준 모듈 시스템인 ESM을 사용하기 위해 export default를 사용합니다.

export default class CustomEventEmitter {
  listeners = {}; // 이벤트를 관리할 마스터 객체 (해시맵 역할)

  on(eventName, fn) {
    // 단축 평가를 활용한 안전한 배열 생성 및 리스너 등록
    this.listeners[eventName] = this.listeners[eventName] || [];
    this.listeners[eventName].push(fn);
    return this; // 메서드 체이닝을 위한 반환
  }

  once(eventName, fn) {
    this.listeners[eventName] = this.listeners[eventName] || [];
    
    // 클로저를 활용한 가짜 포장지(Wrapper) 함수
    const onceWrapper = (...args) => {
      fn(...args); // 가변 인자를 원본 함수로 안전하게 전달
      this.off(eventName, onceWrapper); // 실행 직후 스스로를 배열에서 지워버립니다.
    };
    
    this.listeners[eventName].push(onceWrapper);
    return this;
  }

  off(eventName, fn) {
    let lis = this.listeners[eventName];
    if (!lis) return this;
    
    // 배열 꼬임 현상을 방지하는 역방향 반복문(Reverse Loop) 패턴
    for (let i = lis.length - 1; i >= 0; i--) {
      if (lis[i] === fn) {
        lis.splice(i, 1);
        break;
      }
    }
    return this;
  }

  emit(eventName, ...args) {
    let fns = this.listeners[eventName];
    if (!fns) return false;
    
    // 배열에 담긴 함수들을 하나씩 꺼내어 다중 인자를 전달하며 모두 실행
    fns.forEach((f) => {
      f(...args);
    });
    return true;
  }
}