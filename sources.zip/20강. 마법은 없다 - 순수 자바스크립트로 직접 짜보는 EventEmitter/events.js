// events.js
// Node.js의 구형 방식인 require 대신, 최신 글로벌 표준인 ESM 방식을 사용하기 위해 'export default'를 선언합니다.
export default class CustomEventEmitter {
  
  // 1. 해시맵(딕셔너리) 역할을 하는 마스터 객체
  // 이벤트 이름(키)과 실행할 함수들의 배열(값)을 저장하여, O(1)의 속도로 빠르게 이벤트를 검색합니다.
  listeners = {}; 

  // [메서드 1] 이벤트 구독하기 (on)
  on(eventName, fn) {
    // 단축 평가(A || B) 패턴:
    // this.listeners[eventName]이 이미 존재하면 그대로 쓰고, 
    // 처음 등록하는 이벤트라서 비어있다면([] Falsy) 새로운 빈 배열을 만들어 할당합니다.
    this.listeners[eventName] = this.listeners[eventName] || [];
    
    // 해당 이벤트의 배열 맨 뒤에 실행할 콜백 함수(fn)를 밀어 넣습니다.
    this.listeners[eventName].push(fn);
    
    // 메서드 체이닝(예: 객체.on().on())을 지원하기 위해 객체 자기 자신(this)을 반환합니다.
    return this; 
  }

  // [메서드 2] 딱 한 번만 실행되는 이벤트 구독하기 (once)
  once(eventName, fn) {
    // 배열이 없으면 안전하게 빈 배열을 먼저 생성합니다.
    this.listeners[eventName] = this.listeners[eventName] || [];
    
    // 래퍼(Wrapper) 함수와 클로저(Closure) 패턴:
    // 사용자가 넘긴 함수(fn)를 직접 넣지 않고, 'onceWrapper'라는 가짜 포장지 함수를 만듭니다.
    // 화살표 함수를 썼기 때문에 바깥쪽의 this(CustomEventEmitter)를 안전하게 기억합니다.
    const onceWrapper = (...args) => {
      fn(...args); // 1. 포장지 안에서 원본 함수에 데이터를 안전하게 전달하여 진짜로 실행합니다.
      this.off(eventName, onceWrapper); // 2. 실행 직후, 포장지 스스로를 이벤트 배열에서 지워버립니다(자폭 기능).
    };
    
    // 원본 함수 대신 자폭 기능이 탑재된 포장지 함수를 배열에 밀어 넣습니다.
    this.listeners[eventName].push(onceWrapper);
    return this;
  }

  // [메서드 3] 구독 취소 및 함수 삭제하기 (off)
  off(eventName, fn) {
    let lis = this.listeners[eventName];
    // 지우려는 이벤트 이름의 배열 자체가 없으면 아무 작업도 하지 않고 함수를 끝냅니다.
    if (!lis) return this;
    
    // 역방향 반복문(Reverse Loop) 패턴:
    // 배열의 앞(인덱스 0)부터 지우면 뒤에 있던 요소들이 앞으로 당겨지면서 순서가 꼬이는 치명적인 버그가 발생합니다.
    // 따라서 맨 뒤쪽 요소(length - 1)부터 시작해서 앞(0)으로 거꾸로 오면서 검사하고 지웁니다.
    for (let i = lis.length - 1; i >= 0; i--) {
      // 배열 안의 함수가 지우고자 하는 함수(fn)와 완벽히 일치하면
      if (lis[i] === fn) {
        // splice를 이용해 그 위치(i)에서 1개의 요소를 메모리에서 삭제합니다.
        lis.splice(i, 1);
        break; // 찾아서 지웠으니 반복문을 즉시 중단하여 성능을 아낍니다.
      }
    }
    return this;
  }

  // [메서드 4] 이벤트 알림 발생시키기 (emit)
  // 전개 연산자(...args): 사용자가 인자를 1개 주든, 10개 주든 'args'라는 하나의 튼튼한 배열로 모두 흡수합니다.
  emit(eventName, ...args) {
    let fns = this.listeners[eventName];
    // 등록된 이벤트가 아무것도 없다면 false를 반환하고 즉시 종료합니다.
    if (!fns) return false;
    
    // 배열 안에 담겨있는 모든 콜백 함수들을 하나씩 꺼내어 순서대로 실행합니다.
    fns.forEach((f) => {
      // Spread Operator(...args): 묶여있던 args 배열의 끈을 풀어서, 각각의 인자들을 함수로 흩뿌려 전달합니다.
      f(...args);
    });
    
    // 이벤트가 성공적으로 발생하고 함수들이 실행되었으므로 true를 반환합니다.
    return true;
  }
}