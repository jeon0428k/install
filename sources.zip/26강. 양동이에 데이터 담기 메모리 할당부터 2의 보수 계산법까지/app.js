/**
 * [강의 26강 통합 실습] Buffer와 2의 보수, 그리고 오프셋 제어
 * 실행 방법: node app.js
 */

// 1. 내장 모듈 불러오기 (Node.js 표준 규칙)
import { Buffer } from 'node:buffer';

// 2. 4바이트(32비트) 메모리 공간 할당 (RAM의 미니 배터리 32개 예약)
const memContainer = Buffer.alloc(4);

console.log("--- 1. 초기 할당 상태 (Zero-fill) ---");
console.log(memContainer); // <Buffer 00 00 00 00>
console.log("");


// 3. 16진수 데이터 직접 주입 (배열 인덱스 방식)
console.log("--- 2. 16진수 할당 및 10진수 출력 ---");
memContainer[0] = 0x5a; // 10진수 90
memContainer[1] = 0xc2; // 10진수 194
memContainer[2] = 0x8f; // 10진수 143
memContainer[3] = 0x3e; // 10진수 62

console.log("버퍼 전체(Hex):", memContainer); 
console.log("0번 인덱스(Decimal):", memContainer[0]); // 개별 출력 시 10진수 90으로 변환됨
console.log("");


// 4. 2의 보수(Two's Complement)와 음수 테스트
console.log("--- 3. 음수 할당의 미스터리와 2의 보수 ---");
// 대괄호로 음수 -42를 넣으면 컴퓨터는 내부적으로 '2의 보수' 패턴(11010110)으로 저장합니다.
memContainer[0] = -42;

// 읽을 때 힌트(writeInt8 등)가 없으면, 부호 없는 양수(214)로 착각해서 읽습니다.
console.log("대괄호로 읽은 -42의 결과:", memContainer[0]); // 출력: 214
console.log("실제 메모리에 기록된 비트 패턴(Hex):", memContainer[0].toString(16)); // d6 (이진수 11010110)
console.log("");


// 5. 오프셋(Offset)과 전용 메서드 활용
console.log("--- 4. 정밀한 오프셋 타겟팅 (writeInt8) ---");
// 오프셋 0 위치에 '부호 있는 8비트 정수'임을 명시하며 -42 쓰기
memContainer.writeInt8(-42, 0); 

// 오프셋 2 위치(세 번째 칸)에 점수 100 쓰기
memContainer.writeInt8(100, 2);

console.log("오프셋 적용 후 버퍼:", memContainer); 
// 읽어올 때도 '부호 있음'을 알려주는 readInt8 사용
console.log("오프셋 0에서 읽은 값:", memContainer.readInt8(0)); // -42 (정확히 복원!)
console.log("오프셋 2에서 읽은 값:", memContainer.readInt8(2)); // 100
console.log("");


// 6. 문자열 디코딩 (toString)
console.log("--- 5. 데이터 정제 (toString) ---");
// 버퍼의 모든 데이터를 16진수 문자열 한 줄로 합쳐서 출력
const hexString = memContainer.toString("hex");
console.log("16진수 문자열 변환:", hexString); // "d6c26400"