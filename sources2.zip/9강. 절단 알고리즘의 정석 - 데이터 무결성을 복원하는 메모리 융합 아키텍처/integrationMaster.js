/* ====================================================================
 ⚙️ [시각화 3] 9강 최종 파이프라인 전체 아키텍처
====================================================================
[1. 거대 원본 파일] ➡️ (64KB 펌프) ➡️ [2. RAM 유저 공간]
                                            ⬇️ (toString & split)
                                      [3. leftover 복원 알고리즘]
                                            ⬇️ (.includes 필터링)
[5. 필터링 결과 파일] ⬅️ (16KB 하수구) ⬅️ [4. 백프레셔(pause/resume) 통제]
====================================================================*/

/**
 * [integrationMaster.mjs]
 * 9강: 데이터 절단(파편화) 복구 알고리즘 및
 * 메모리 융합 백프레셔 아키텍처 (최종 완성본)
 */
import fs from "node:fs/promises";
import { finished } from "node:stream/promises";

async function runIntegrationMaster() {
  const SOURCE_FILE = "massive_server_logs.txt";
  const DEST_FILE = "filtered_errors.txt";
  const TOTAL_LOGS = 200000; // 약 16MB 거대 원본 생성용

  // =====================================================================
  // Phase 1: 거대한 원본 로그 파일 생성 (동기적 완벽 보장)
  // =====================================================================
  console.log("▶️ 1. 거대한 원본 로그 파일(댐) 생성 중...");
  console.time("생성_시간");
  const fileHandleWriteOrigin = await fs.open(SOURCE_FILE, "w");
  const writeStreamOrigin = fileHandleWriteOrigin.createWriteStream();

  for (let i = 0; i < TOTAL_LOGS; i++) {
    const logType = i % 2 === 0 ? "INFO" : "ERROR";
    const message =
      logType === "INFO"
        ? "데이터 처리가 정상적으로 완료되었습니다."
        : "Network Card Connection Timeout 발생!";
    // 💡 핵심: 이중 공백으로 확실한 구분선 생성
    const data = `[${logType}] 시스템 식별자 ${i} - ${message}  `;

    if (!writeStreamOrigin.write(data)) {
      await new Promise((resolve) => writeStreamOrigin.once("drain", resolve));
    }
  }
  writeStreamOrigin.end();
  await finished(writeStreamOrigin);
  await fileHandleWriteOrigin.close();
  console.timeEnd("생성_시간");
  console.log("✅ 로그 파일 생성 완료!\\n");

  // =====================================================================
  // Phase 2: 무결성 복구 알고리즘 및 백프레셔 필터링 아키텍처
  // =====================================================================
  console.log("▶️ 2. 취수 펌프 가동 및 알고리즘 필터링 시작...");
  console.time("분석_필터링_소요시간");

  const fileHandleRead = await fs.open(SOURCE_FILE, "r");
  const fileHandleWriteDest = await fs.open(DEST_FILE, "w");

  const streamRead = fileHandleRead.createReadStream({
    highWaterMark: 64 * 1024,
  });
  const streamWrite = fileHandleWriteDest.createWriteStream();

  let chunkCount = 0;
  let errorCount = 0;
  let leftover = ""; // 💡 [단계 1] 끊어진 다리를 연결할 전역 임시 보관소

  streamRead.on("data", (chunk) => {
    chunkCount++;
    // 💡 [단계 2] 0과 1을 문자로 번역하고 이중 공백으로 무자비하게 쪼갬
    const logs = chunk.toString("utf-8").split("  ");

    // 💡 [단계 3] 이전 청크에서 잘린 꼬리가 있다면 현재 배열 앞머리와 결합 (퍼즐 복구)
    if (leftover !== "") {
      logs[0] = leftover + logs[0];
    }

    // 💡 [단계 4] 현재 배열의 마지막 요소는 100% 꼬리가 잘린 쓰레기 데이터이므로
    // 선제적으로 빼내어(pop) 다음 청크를 위해 보관!
    leftover = logs.pop();

    // 💡 [단계 5 & 6] 이제 온전해진 문장만 순회하며 에러 필터링 및 백프레셔 통제
    logs.forEach((log) => {
      if (log.includes("[ERROR]")) {
        errorCount++;
        // 16KB 쓰기 버퍼가 꽉 차서 false를 반환하면?
        if (!streamWrite.write(log + "  ")) {
          // 펌프 일시 정지 (메모리 붕괴 완벽 차단)
          streamRead.pause();
        }
      }
    });
  });

  // OS가 쓰기 버퍼의 물을 싹 빼주면 다시 펌프 가동
  streamWrite.on("drain", () => streamRead.resume());

  // =====================================================================
  // Phase 3: 마지막 자투리 구원 및 파이프라인 철거
  // =====================================================================
  streamRead.on("end", async () => {
    // 💡 [마지막 단계] pop으로 빼둔 마지막 꼬리는 결합될 기회가 없으므로 여기서 단독 검사
    if (leftover.includes("[ERROR]")) {
      errorCount++;
      streamWrite.write(leftover + "  ");
    }

    // 찌끄러기 밀어내고 쓰기 파이프 닫기
    streamWrite.end();
    await finished(streamWrite);

    // OS 자원(번호표) 안전하게 반납
    await fileHandleRead.close();
    await fileHandleWriteDest.close();

    console.timeEnd("분석_필터링_소요시간");
    console.log("\\n========================================================");
    console.log("🎉 [최종 리포트] 분석 작업이 완벽하게 끝났습니다!");
    console.log(`- 퍼 올린 64KB 청크 횟수: ${chunkCount}회`);
    console.log(
      `- 추출해 낸 에러 메시지: 정확히 ${errorCount.toLocaleString()}개`,
    );
    console.log("========================================================\\n");

    // 다음 실습을 위해 원본 파일만 삭제 (결과 파일은 남겨둠)
    await fs.unlink(SOURCE_FILE);
    console.log(
      "📂 팁: 테스트가 끝났습니다! 작업 폴더에 남겨진 'filtered_errors.txt' 파일을 직접 열어보세요!",
    );
  });
}

runIntegrationMaster().catch(console.error);
