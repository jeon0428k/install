import { writeFileSync } from "node:fs";

const fileName = "high_performance_output.txt";
const chunkData = "이것은 Node.js 스트림 성능 테스트를 위한 무거운 더미 텍스트 데이터입니다. 데이터 흐름을 통제하는 아키텍트가 되어봅시다.\\n".repeat(1000);

console.log("⏳ 테스트용 거대 더미 파일 생성 중... 잠시만 기다려주세요.");

// 약 100MB 크기의 파일을 만들기 위해 반복해서 파일 끝에 이어붙이기(Append)
for (let i = 0; i < 700; i++) {
  writeFileSync(fileName, chunkData, { flag: "a" });
}

console.log(`✅ [사전 준비 완료] ${fileName} 파일이 성공적으로 생성되었습니다! (약 100MB)`);