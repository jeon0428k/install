import { Readable } from "node:stream";
import { open, read, close } from "node:fs";

// =====================================================================
// 1. 완벽하게 통제된 Custom Readable Stream 클래스 정의
// =====================================================================
class SmartDiskReader extends Readable {
  constructor({ highWaterMark, sourceFileName }) {
    super({ highWaterMark });

    this.sourceFileName = sourceFileName;
    this.fileDescriptor = null;
  }

  // 생명주기 1: 권한 획득 (파이프라인 개통)
  _construct(callback) {
    open(this.sourceFileName, "r", (error, fd) => {
      if (error) {
        callback(error);
      } else {
        this.fileDescriptor = fd;
        callback();
      }
    });
  }

  // 생명주기 2: 펌프질 엔진 가동 (chunk 단위로 퍼 올림)
  _read(size) {
    // RAM에 빈 바가지 할당 (초고속 Unsafe 적용)
    const tempBuffer = Buffer.allocUnsafe(size);

    // OS 커널에 디스크 읽기 명령
    read(this.fileDescriptor, tempBuffer, 0, size, null, (error, bytesRead) => {
      if (error) {
        return this.destroy(error); // 에러 시 파괴
      }

      if (bytesRead > 0) {
        // 실제 물이 담긴 만큼만 메모리 공유 뷰(View) 생성
        const actualData = tempBuffer.subarray(0, bytesRead);
        this.push(actualData); // 다음 단계로 데이터 방출
      } else {
        this.push(null); // 파일 끝(EOF) 도달, 펌프 정지 선언
      }
    });
  }

  // 생명주기 3: 자원 반납 (스트림 파괴 시 최후 실행)
  _destroy(error, callback) {
    if (this.fileDescriptor !== null) {
      close(this.fileDescriptor, (closeError) => {
        callback(closeError || error);
      });
    } else {
      callback(error);
    }
  }
}

// =====================================================================
// 2. 읽기 벤치마크 실행 및 이벤트 리스닝 로직
// =====================================================================
console.log("▶️ 펌프 가동 준비 중...");
console.time("Custom Stream Read Time");

// 64KB의 바가지를 가진 펌프 조립
const stream = new SmartDiskReader({
  highWaterMark: 1024 * 64, // 64KB
  sourceFileName: "high_performance_output.txt", // 15강에서 만든 결과물 대상
});

let totalChunks = 0;
let totalBytes = 0;

// [핵심 트리거] 'data' 이벤트 리스너를 다는 순간, 펌프 모터가 가동을 시작합니다!
stream.on("data", (chunk) => {
  ++totalChunks;
  totalBytes += chunk.length;
});

// 파일의 끝에 도달하여 펌프가 멈추었을 때 실행
stream.on("end", () => {
  console.log(`\n✅ 데이터 읽기 완료!`);
  console.log(`- 펌프 작동(Chunk 쪼개기) 횟수: ${totalChunks}회`);
  console.log(
    `- 총 읽어들인 용량: ${(totalBytes / 1024 / 1024).toFixed(2)} MB`,
  );
  console.timeEnd("Custom Stream Read Time");
});

// 자원 정리가 완전히 끝났을 때
stream.on("close", () => {
  console.log("🔒 OS 권한 티켓 반납 완료 (File Lock 방어 성공)\\n");
});
