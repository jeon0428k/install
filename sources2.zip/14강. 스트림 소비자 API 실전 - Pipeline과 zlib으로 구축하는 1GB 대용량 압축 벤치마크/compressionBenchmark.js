/**
 * [compressionBenchmark.js]
 * 14강: 1GB 파일 생성 및 Pipeline 기반 다중 압축 벤치마크 테스트
 */
import { createWriteStream, createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { pipeline } from "node:stream/promises";
import zlib from "node:zlib";

// 1. 1GB 더미 파일 생성기
async function createDummyFile(filePath) {
  console.log("⏳ 1GB 더미 텍스트 파일 생성을 시작합니다...");
  console.time("Dummy Generation Time");

  const writeStream = createWriteStream(filePath);
  const chunk = Buffer.alloc(1024 * 1024, "A"); // 1MB 바가지

  for (let i = 0; i < 1024; i++) {
    // 1024번 반복 = 1GB
    const canWrite = writeStream.write(chunk);
    if (!canWrite) {
      await new Promise((resolve) => writeStream.once("drain", resolve));
    }
  }

  writeStream.end();
  await new Promise((resolve) => writeStream.on("finish", resolve));

  console.timeEnd("Dummy Generation Time");
  console.log(`✅  더미 파일 생성 완료: ${filePath}\\n`);
}

// 2. 만능 압축 벤치마크 파이프라인
async function measureCompression(
  algoName,
  transformFilter,
  inputFile,
  extension,
) {
  const outputFile = `compressed_${algoName}.${extension}`;
  console.log(`▶️  [${algoName}] 파이프라인 가동 중...`);
  console.time(`[${algoName}] 소요 시간`);

  try {
    await pipeline(
      createReadStream(inputFile),
      transformFilter,
      createWriteStream(outputFile),
    );
  } catch (error) {
    console.error(`❌  [${algoName}] 파이프라인 에러 발생:`, error);
    return;
  }
  console.timeEnd(`[${algoName}] 소요 시간`);

  const originalSize = (await stat(inputFile)).size;
  const compressedSize = (await stat(outputFile)).size;

  const originalMB = (originalSize / (1024 * 1024)).toFixed(2);
  const compressedMB = (compressedSize / (1024 * 1024)).toFixed(2);
  const ratio = ((compressedSize / originalSize) * 100).toFixed(4);

  console.log(
    `📊  [${algoName}] 압축률: ${ratio}% (원본: ${originalMB}MB -> 압축: ${compressedMB}MB)\\n`,
  );
}

// 3. 메인 실행 함수
(async () => {
  const TARGET_FILE = "dummy_1gb.txt";

  await createDummyFile(TARGET_FILE);
  console.log("🚀  다중 알고리즘 스트림 압축 벤치마크를 시작합니다.\\n");

  await measureCompression("Gzip", zlib.createGzip(), TARGET_FILE, "gz");
  await measureCompression(
    "Deflate",
    zlib.createDeflate(),
    TARGET_FILE,
    "deflate",
  );
  await measureCompression(
    "Brotli",
    zlib.createBrotliCompress(),
    TARGET_FILE,
    "br",
  );

  console.log("🎉  모든 데이터 파이프라인 처리가 안전하게 완료되었습니다.");
})();
