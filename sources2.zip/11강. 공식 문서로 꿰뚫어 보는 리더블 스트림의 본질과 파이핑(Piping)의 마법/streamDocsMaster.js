/**
 * [streamDocsMaster.mjs]
 * 11강: 공식 문서의 핵심 개념(Flowing/Paused 전환 및 안티 패턴) 실습 확인
 */
import fs from "node:fs/promises";
import { StringDecoder } from "node:string_decoder"; // 💡 10강의 핵심 도구! 한글 깨짐 방지 모듈

async function runStreamDocsMaster() {
  const TEST_FILE = "test_abstract.txt";
  await fs.writeFile(
    TEST_FILE,
    "이 데이터는 스트림의 본질을 테스트하기 위한 문장입니다.",
  );

  console.log("▶️ 1. 스트림 초기 상태 확인 (Paused 모드)");
  const fileHandle = await fs.open(TEST_FILE, "r");
  const streamRead = fileHandle.createReadStream();

  console.log(
    `- 생성 직후 상태 (readableFlowing): ${streamRead.readableFlowing}`,
  );
  // 예상 출력: null (소비자 없음)

  // =====================================================================
  console.log("\n▶️ 2. Flowing 모드 전환 및 백프레셔(pause) 테스트");

  streamRead.on("data", (chunk) => {
    console.log(
      `- 'data' 이벤트 부착 후 상태: ${streamRead.readableFlowing} (Flowing 모드!)`,
    );
    console.log(`- 읽어온 데이터 크기: ${chunk.length} Bytes`);

    // 고의로 흐름을 멈춰봄
    streamRead.pause();
    console.log(
      `- pause() 호출 직후 상태: ${streamRead.readableFlowing} (Paused 모드 복귀)`,
    );

    // 다시 흐름 재개
    streamRead.resume();
  });

  streamRead.on("end", async () => {
    console.log(`- 파일 바닥(EOF) 도달 후 상태: ${streamRead.readableFlowing}`);
    await fileHandle.close();

    // =====================================================================
    console.log("\n▶️ 3. 🚨 끔찍한 안티 패턴의 파괴력 확인 (Push와 Pull 혼용)");
    await runAntiPatternTest(TEST_FILE);
  });
}

// ❌ 절대 따라 하지 마세요! 안티 패턴 시뮬레이션
async function runAntiPatternTest(fileName) {
  const fileHandle = await fs.open(fileName, "r");
  // 의도적으로 아주 작은 4Byte 단위로 기계적 칼질을 만듭니다. (무조건 한글이 쪼개짐!)
  const badStream = fileHandle.createReadStream({ highWaterMark: 4 });

  // 💡 터미널 한글 깨짐()을 막기 위해 10강에서 배운 디코더를 장착합니다!
  const decoder = new StringDecoder("utf-8");

  let dataEventCount = 0;

  // 방식 1: Push (Flowing 모드)
  badStream.on("data", (chunk) => {
    dataEventCount++;
    // chunk.toString() 대신 decoder.write()를 사용하여 한글 파괴를 막아냅니다.
    console.log(
      `  🌊 [data 이벤트] 밀어낸 조각 ${dataEventCount}:`,
      decoder.write(chunk),
    );
  });

  // 방식 2: Pull (Paused 모드 - 수동 퍼내기)
  badStream.on("readable", () => {
    const chunk = badStream.read();
    if (chunk) {
      // 여기도 디코더를 사용하여 안전하게 번역합니다.
      console.log(
        `  🪣 [readable + read()] 강제로 퍼낸 조각:`,
        decoder.write(chunk),
      );
    }
  });

  badStream.on("end", async () => {
    // 버퍼에 킵(keep)해둔 마지막 바이트 찌꺼기를 털어냅니다.
    const leftover = decoder.end();
    if (leftover) console.log(`  🧹 [남은 자투리 털어내기]:`, leftover);

    console.log(
      "\n💥 결론: 디코더 덕분에 한글은 안 깨졌지만, 단일 버퍼를 두고",
    );
    console.log(
      "두 이벤트가 경합을 벌이면서 데이터의 '순서'가 완전히 박살 났습니다!",
    );
    console.log("실무에서 이런 코드를 짜면 장애 원인을 절대 찾을 수 없습니다.");
    await fileHandle.close();
    await fs.unlink(fileName); // 테스트용 파일 삭제 클린업
  });
}

runStreamDocsMaster().catch(console.error);
