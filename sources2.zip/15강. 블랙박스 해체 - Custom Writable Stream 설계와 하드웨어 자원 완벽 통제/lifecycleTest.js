import { Writable } from "node:stream";

// 오직 생명주기 확인만을 위한 초경량 Tracker 클래스
class LifecycleTracker extends Writable {
  constructor(options) {
    super(options);
    console.log("🟢  [1. 생성] constructor 호출: 스트림 인스턴스 뼈대 생성");
  }

  _construct(callback) {
    console.log(
      "🛠️  [2. 초기화] _construct 호출: 파이프라인 개통 준비 완료 (가상 권한 획득)",
    );
    callback(); // 다음 단계로 넘어가도 좋다는 승인
  }

  _write(chunk, encoding, callback) {
    console.log(
      `✍️  [3. 쓰기 엔진 가동] _write 호출: 유입된 데이터 -> "${chunk.toString()}"`,
    );
    callback(); // 이 데이터 처리 끝났음 승인
  }

  _final(callback) {
    console.log(
      "🏁 [4. 잔여물 청소] _final 호출: stream.end()가 감지됨! 남은 데이터 밀어냄",
    );
    callback(); // 청소 끝 승인
  }

  _destroy(error, callback) {
    console.log(
      `💥 [5. 파이프 파괴] _destroy 호출: 모든 자원 해제 완료. (에러 유무: ${error ? error.message : "없음 (정상 종료)"})`,
    );
    callback(error);
  }
}

// === 실행 영역 ===
console.log("▶️ --- 생명주기 추적 테스트 시작 ---\\n");

const tracker = new LifecycleTracker();

// 데이터 두 번 밀어넣기
tracker.write("Hello ");
tracker.write("World!");

// 더 이상 보낼 데이터가 없음을 선언하며 마지막 조각 주입
tracker.end(" (Stream 끝!)");
