// customWritableMaster.js
import { Writable } from "node:stream";
import { open, write, close } from "node:fs";

// =====================================================================
// 1. 완벽하게 통제된 Custom Writable Stream 클래스 정의
// =====================================================================
class SmartDiskWriter extends Writable {
  constructor({ highWaterMark, destination }) {
    super({ highWaterMark }); // 부모 클래스에 최고 수위선 전달

    this.destination = destination; // 최종 저장 경로
    this.fileDescriptor = null; // 권한 번호표 초기화
    this.ramBuffer = []; // RAM 완충 공간
    this.bufferedBytes = 0; // 현재 모인 바이트 수
    this.ioCount = 0; // 디스크 I/O 접근 횟수 카운트
  }

  // 생명주기 1: 권한 획득 (파이프라인 개통)
  _construct(callback) {
    open(this.destination, "w", (error, fd) => {
      if (error) {
        callback(error);
      } else {
        this.fileDescriptor = fd;
        callback();
      }
    });
  }

  // 생명주기 2: 버퍼링 엔진 가동 (데이터 유입 시마다 반복)
  _write(chunk, encoding, callback) {
    this.ramBuffer.push(chunk);
    this.bufferedBytes += chunk.length;

    // 수위선을 초과했다면 뭉쳐서 디스크로 배출 (Context Switching 방어)
    if (this.bufferedBytes > this.writableHighWaterMark) {
      write(this.fileDescriptor, Buffer.concat(this.ramBuffer), (error) => {
        if (error) return callback(error);

        this.ramBuffer = []; // 배출 완료 후 버퍼 비우기
        this.bufferedBytes = 0;
        ++this.ioCount; // I/O 발생 카운트 증가
        callback();
      });
    } else {
      // 안 넘쳤다면 디스크 접근 없이 즉시 다음 청크 대기
      callback();
    }
  }

  // 생명주기 3: 잔여물 청소 (stream.end 호출 시 1회 실행)
  _final(callback) {
    // RAM 버퍼에 남은 찌끄러기 데이터가 있다면 마저 배출
    if (this.bufferedBytes > 0) {
      write(this.fileDescriptor, Buffer.concat(this.ramBuffer), (error) => {
        if (error) return callback(error);

        ++this.ioCount;
        this.ramBuffer = [];
        this.bufferedBytes = 0;
        callback();
      });
    } else {
      callback();
    }
  }

  // 생명주기 4: 자원 반납 (스트림 종료 시 최후 실행)
  _destroy(error, callback) {
    console.log(`\n📊 최종 하드웨어 벤치마크 결과`);
    console.log(`- 물리적 디스크 I/O 횟수: ${this.ioCount}회`);

    // OS 자원(fd)을 반드시 반납하여 Memory Leak 방지
    if (this.fileDescriptor !== null) {
      close(this.fileDescriptor, (closeError) => {
        callback(closeError || error);
      });
    } else {
      callback(error);
    }
  }
}

// =====================================================================
// 2. 100만 번 쓰기 폭격 및 백프레셔 방어 테스트 (벤치마크 실행)
// =====================================================================
console.time("Custom Stream Write Time");

// 64KB의 물탱크를 가진 엔진 가동
const stream = new SmartDiskWriter({
  highWaterMark: 1024 * 64,
  destination: "high_performance_output.txt",
});

let currentIndex = 0;
const MAX_WRITE_COUNT = 1000000;
let backpressureCount = 0;

// 백프레셔를 고려한 안전한 쓰기 엔진 릴레이 함수
const executeWriting = () => {
  while (currentIndex < MAX_WRITE_COUNT) {
    // 인간이 읽을 수 있는 문자열 버퍼 생성
    const chunk = Buffer.from(` ${currentIndex} `, "utf-8");

    // 마지막 인덱스 도달 시 end() 호출하여 _final로 넘김
    if (currentIndex === MAX_WRITE_COUNT - 1) {
      return stream.end(chunk);
    }

    // 데이터 주입! 반환값이 false라면 물탱크가 가득 찼다는 백프레셔 알림
    const canKeepWriting = stream.write(chunk);

    // 물탱크가 꽉 찼다면 즉시 루프 탈출 (RAM 붕괴 완벽 차단)
    if (!canKeepWriting) {
      break;
    }

    ++currentIndex;
  }
};

// 최초 실행
executeWriting();

// OS가 디스크로 물을 다 비워주면 발생하는 drain 이벤트 감지
stream.on("drain", () => {
  ++backpressureCount;
  executeWriting(); // 멈췄던 지점부터 다시 루프 재가동 (논블로킹 릴레이)
});

// 논리적 데이터 처리가 완료되었을 때 발생
stream.on("finish", () => {
  console.log(`- Backpressure (Drain) 방어 횟수: ${backpressureCount}회`);
});

// [핵심] 자원 정리(_destroy 내부 close)가 모두 끝나는 진짜 종료 시점
stream.on("close", () => {
  console.timeEnd("Custom Stream Write Time");
});
