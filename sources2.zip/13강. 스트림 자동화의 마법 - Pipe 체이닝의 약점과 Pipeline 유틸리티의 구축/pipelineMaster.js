/**
 * [pipelineMaster.mjs]
 * 13강: Pipeline 유틸리티를 활용한 궁극의 파일 복사와 연쇄 에러 방어 테스트
 */
import fs from "node:fs/promises";
import { createReadStream, createWriteStream } from "node:fs";
import { pipeline } from "node:stream/promises";

async function runPipelineMaster() {
  const SOURCE_FILE = "source.txt";
  const TARGET_FILE = "target.txt";
  
  // =====================================================================
  // Phase 1: 테스트용 거대 원본 파일 생성 (약 50MB)
  // =====================================================================
  console.log("▶️  1. 테스트용 거대 원본 파일 생성 중...");
  const sourceFileHandle = await fs.open(SOURCE_FILE, "w");
  const initStream = sourceFileHandle.createWriteStream();

  for (let i = 0; i < 500000; i++) {
    // 거대한 더미 데이터를 쓰기 버퍼에 쏟아 붓습니다.
    if (!initStream.write(`Pipeline Test Data Log Index: ${i}\n`)) {
      await new Promise((resolve) => initStream.once("drain", resolve));
    }
  }
  initStream.end();
  await sourceFileHandle.close();
  console.log("✅ 원본 파일 생성 완료!\n");

  // =====================================================================
  // Phase 2: Pipeline 마법의 1줄 코드 복사!
  // =====================================================================
  console.log("▶️  2. Pipeline을 활용한 마법의 1줄 고속 복사 시작!");
  console.time("정상_파이프라인_소요시간");

  const readStream = createReadStream(SOURCE_FILE);
  const writeStream = createWriteStream(TARGET_FILE);

  try {
    // 💡 12강의 그 모든 복잡한 과정을 단 한 줄로 끝냅니다!
    // 내부적으로 백프레셔 제어와 메모리 최적화가 알아서 수행됩니다.
    await pipeline(readStream, writeStream);
    console.log("🎉 정상 파이프라인 데이터 복사가 완벽하게 완료되었습니다.");
  } catch (err) {
    console.error("에러 발생:", err);
  }

  console.timeEnd("정상_파이프라인_소요시간");

  // =====================================================================
  // Phase 3: 고의로 에러를 발생시키는 파괴 테스트 (안전망 증명)
  // =====================================================================
  console.log("\n▶️  3. 🚨 고의 에러 발생 테스트: 연쇄 파괴 방어 시스템 가동");
  
  const badReadStream = createReadStream(SOURCE_FILE);
  const badWriteStream = createWriteStream("error_target.txt");

  // 💡 Pipeline이 정말로 관련된 스트림들을 연쇄적으로 닫아주는지 확인하기 위한 리스너
  badWriteStream.on("close", () => {
    console.log("   [시스템 로그] 🗑️  목적지 쓰기 스트림(하수구)이 Pipeline에 의해 강제로 닫혔습니다!");
  });

  // 0.1초 뒤에 펌프(원본 스트림)를 망가뜨리는 끔찍한 에러를 강제로 주입해 봅니다.
  setTimeout(() => {
    console.log("   [시뮬레이션] ⚡ 0.1초 경과: 원본 읽기 스트림에 치명적 네트워크 단절 에러 강제 주입!");
    badReadStream.destroy(new Error("네트워크 연결 끊김 (Timeout)"));
  }, 100);

  try {
    // Pipeline이 에러를 감지하고 badWriteStream(하수구)까지 
    // 알아서 안전하게 연쇄 파괴하는지 지켜봅니다.
    await pipeline(badReadStream, badWriteStream);
    
    // 에러가 났으므로 이 아래 코드는 절대 실행되지 않습니다.
    console.log("이 문구가 출력되면 Pipeline 안전망이 뚫린 겁니다!"); 
  } catch (err) {
    console.log(`\n🛡️ [Pipeline 안전망 발동 완벽 분석]`);
    console.error(`- ❌ 어디서 오류가 났는가?: 원본 읽기 펌프 (badReadStream)`);
    console.error(`- ❌ 어떻게 오류가 났는가?: ${err.message}`);
    console.log(`- ✅ 결과 요약: Pipeline이 에러를 즉시 감지하여 중앙에서 흐름을 차단하고, 연결된 목적지 하수구 파이프까지 연쇄적으로 파괴하여 시스템 자원(FD)을 완벽하게 회수했습니다. 서버는 안전합니다!`);
  }

  // 테스트 후 클린업 (파일 삭제)
  await fs.unlink(SOURCE_FILE).catch(()=>{});
  await fs.unlink(TARGET_FILE).catch(()=>{});
  await fs.unlink("error_target.txt").catch(()=>{});
}

runPipelineMaster().catch(console.error);