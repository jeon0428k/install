/**
 * [streamManual.mjs]
 * 6강: Writable Stream 생명주기 이벤트 및 고급 제어(cork, destroy) 마스터
 */
import fs from "node:fs/promises";
import { finished } from "node:stream/promises";

async function runStreamManual() {
  console.log("▶️ [6강 마스터 스크립트 시작] Writable Stream 블랙박스 해체\\n");

  const TARGET_FILE = "advanced_logs.txt";
  const fileHandle = await fs.open(TARGET_FILE, "w");
  const stream = fileHandle.createWriteStream();

  // =====================================================================
  // 1. ⏱️ 생명주기(Lifecycle) 이벤트 리스너 등록 (관찰 모드)
  // =====================================================================
  stream.on("drain", () =>
    console.log(
      "   🔔 [이벤트] drain: 버퍼 물이 쫙 빠졌습니다! (백프레셔 해소)",
    ),
  );
  stream.on("finish", () =>
    console.log(
      "   🔔 [이벤트] finish: 마지막 자투리 데이터까지 디스크 전송 완료!",
    ),
  );
  stream.on("close", () =>
    console.log(
      "   🔔 [이벤트] close: OS 자원(파일 핸들) 완벽 회수 및 파이프 닫힘!",
    ),
  );
  stream.on("error", (err) =>
    console.log(`   🚨 [이벤트] error 발생: ${err.message}`),
  );

  // =====================================================================
  // 2. 🛠️ cork() 와 uncork()를 활용한 네이글(Nagle) 최적화 시뮬레이션
  // =====================================================================
  console.log(
    "➡️ [명령] stream.cork() 호출: 파이프 마개를 닫고 RAM에 데이터를 뭉칩니다.",
  );
  stream.cork();

  // 아주 작은 데이터를 엄청나게 많이 쓸 때, 매번 디스크로 안 보내고 RAM에 모아둠
  stream.write("[조각 1] ");
  stream.write("[조각 2] ");
  stream.write("[조각 3] ");

  // 상태 프로퍼티 스캔: 아직 디스크로 안 갔지만 RAM에 데이터가 있음을 확인
  console.log(
    `📊 [상태 스캔] 현재 뭉쳐진 RAM 버퍼 용량: ${stream.writableLength} Bytes`,
  );

  console.log(
    "➡️ [명령] stream.uncork() 호출: 마개를 뽑고 뭉친 데이터를 단 한 번의 시스템 콜로 밀어냅니다!",
  );
  stream.uncork();

  // =====================================================================
  // 3. 💥 비상 정지 destroy() 시뮬레이션
  // =====================================================================
  console.log("\\n➡️ [가상 시나리오] 갑작스러운 치명적 에러 발생 가정!");
  console.log(
    "➡️ [명령] stream.destroy() 호출: 파이프를 산산조각 내어 비상 정지합니다.",
  );

  // 파이프 파괴! 내부 찌꺼기는 가비지 컬렉터에 버려지고, 즉각적으로 error와 close 이벤트를 뿜습니다.
  stream.destroy(new Error("시스템 비상 정지. 메모리 누수 방지 가동."));

  // =====================================================================
  // 4. 프로퍼티(상태) 최종 확인
  // =====================================================================
  setTimeout(async () => {
    console.log("\\n📊 [최종 상태 스캔]");
    console.log(
      `- 파이프가 비정상 파괴되었는가? (writableAborted): ${stream.writableAborted}`,
    );
    console.log(`- 쓰기 가능한 상태인가? (writable): ${stream.writable}`);

    // 파일 핸들 반납 (안전)
    await fileHandle.close();
    console.log("\\n✅ [종료] 마스터 스크립트가 안전하게 종료되었습니다.");
  }, 100); // 이벤트 발생 순서를 확인하기 위해 아주 짧은 딜레이 부여
}

// 스크립트 실행
runStreamManual().catch(console.error);
