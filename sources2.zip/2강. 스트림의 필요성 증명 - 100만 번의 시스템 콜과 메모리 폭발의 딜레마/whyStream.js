/**
 * [whyStream.js]
 * Node.js 스트림 및 시스템 콜(I/O) 성능/메모리 비교 실험 코드
 * * ⚠️ 주의: 100만 번의 파일 쓰기가 동시에 겹치지 않도록,
 * 하단의 '실행부'에서 반드시 한 번에 하나의 함수만 주석을 해제하고 테스트하세요.
 */

import fs from "node:fs";
import fsPromises from "node:fs/promises";
import { finished } from "node:stream/promises";

const TARGET_FILE = "server_logs.txt";
const MAX_ITERATION = 1000000;

// =========================================================================
// 1. 프로미스 기반 비동기 방식 (안전하지만 몹시 느림)
// =========================================================================
async function runPromiseVersion() {
  console.log("▶️ [1. Promise 방식] 시작...");
  console.time("1_Promise_작업시간");

  // 커널에 파일 생성 요청을 보내고 번호표(FileHandle)를 발급받음
  const fileHandle = await fsPromises.open(TARGET_FILE, "w");

  for (let i = 0; i < MAX_ITERATION; i++) {
    // [병목 지점] 매번 디스크에 물리적으로 기록될 때까지 메인 셰프(CPU)가 대기함
    await fileHandle.write(
      `[시스템 로그] 유저 ${i}님의 데이터 처리가 완료되었습니다.\n`,
    );
  }

  await fileHandle.close(); // 사용이 끝난 번호표를 운영체제에 반납 (메모리 누수 방지)

  console.timeEnd("1_Promise_작업시간");
  console.log("✅ 완료! (안전하지만 시간이 너무 오래 걸려 실무 도입 불가)\n");
}

// =========================================================================
// 2. 비동기 콜백 방식 (❌ 절대 사용 금지: 메모리 폭발 및 순서 오염)
// =========================================================================
function runCallbackVersion() {
  console.log("▶️ [2. Callback 방식] 시작...");
  console.time("2_Callback_작업시간");

  fs.open(TARGET_FILE, "w", (err, fd) => {
    if (err) throw err;

    for (let i = 0; i < MAX_ITERATION; i++) {
      // await가 없으므로 100만 개의 쓰기 요청을 스레드 풀에 한꺼번에 융단 폭격
      // -> 한정된 RAM에 데이터가 순식간에 쌓이며 OOM(메모리 초과) 발생 위험
      // -> 커널 레벨에서 쓰기 순서가 보장되지 않아 로그 데이터 오염 발생
      fs.write(
        fd,
        `[시스템 로그] 유저 ${i}님의 데이터 처리가 완료되었습니다.\n`,
        (err) => {
          if (err) throw err;
        },
      );
    }
    console.log(
      "⚠️ 100만 개의 콜백을 백그라운드에 던졌습니다. (서버 강제 종료 위험)",
    );
  });

  // 파일이 열리기도 전에, 그리고 쓰기가 끝나기도 전에 타이머가 즉시 종료됨 (무의미한 측정)
  console.timeEnd("2_Callback_작업시간");
}

// =========================================================================
// 3. 동기식(Sync) 방식 (❌ 절대 사용 금지: 서버 프리징 발생)
// =========================================================================
function runSyncVersion() {
  console.log("▶️ [3. Sync 방식] 시작...");
  console.time("3_Sync_작업시간");

  // 메인 스레드를 멈춰 세우고(Blocking) 파일 번호표를 받아옴
  const fd = fs.openSync(TARGET_FILE, "w");

  for (let i = 0; i < MAX_ITERATION; i++) {
    // [치명적 문제] 로그가 디스크에 써지는 동안 V8 엔진(메인 스레드)이 그 자리에 얼어붙음
    // -> 이 시간 동안 다른 유저는 웹사이트 접속(API 요청) 불가
    fs.writeSync(
      fd,
      `[시스템 로그] 유저 ${i}님의 데이터 처리가 완료되었습니다.\n`,
    );
  }

  fs.closeSync(fd);

  console.timeEnd("3_Sync_작업시간");
  console.log("✅ 완료! (속도는 빠르나, 실행되는 동안 서버가 완전히 마비됨)\n");
}

// =========================================================================
// 4. 잘못된 스트림 방식 (❌ 절대 사용 금지: 숨겨진 메모리 폭주)
// =========================================================================
async function runBadStream() {
  console.log("▶️ [4. Bad Stream 방식] 시작...");
  console.time("4_BadStream_작업시간");

  const fileHandle = await fsPromises.open(TARGET_FILE, "w");
  const stream = fileHandle.createWriteStream(); // 16KB 내부 버퍼 생성

  for (let i = 0; i < MAX_ITERATION; i++) {
    // 디스크가 처리하는 속도를 무시하고 16KB RAM 버퍼에 100만 개를 0.1초 만에 때려 박음
    // 내부적으로 false(버퍼 초과)를 반환하지만 무시하고 강행 -> 메모리 터짐
    stream.write(`[시스템 로그] 유저 ${i}님의 데이터 처리가 완료되었습니다.\n`);
  }

  console.timeEnd("4_BadStream_작업시간");
  console.log(
    "⚠️ 완료된 것처럼 보이지만, 사실 커널이 백그라운드에서 힘겹게 옮겨 적는 중입니다. (메모리 폭주)\n",
  );
}

// =========================================================================
// 5. 🏆 최종 해결책: 스트림 + 백프레셔 제어 (✅ 실무 권장 방식)
// =========================================================================
async function runOptimalStream() {
  console.log("▶️ [5. Optimal Stream (백프레셔 제어) 방식] 시작...");
  console.time("5_OptimalStream_작업시간");

  // 파일 핸들 획득과 스트림 파이프 생성을 한 번에 깔끔하게 처리 (기본 16KB 버퍼)
  const stream = fs.createWriteStream(TARGET_FILE);

  for (let i = 0; i < MAX_ITERATION; i++) {
    const data = `[시스템 로그] 유저 ${i}님의 데이터 처리가 완료되었습니다.\n`;

    // [핵심 흐름 제어] 버퍼 한계치(16KB)를 초과하여 false가 반환(백프레셔 발생)되면
    if (!stream.write(data)) {
      // 무작정 붓기를 멈추고, 커널이 디스크로 물을 다 빼내어 버퍼가 비워질 때(drain)까지 대기
      await new Promise((resolve) => stream.once("drain", resolve));
    }
  }

  // 100만 번의 쓰기가 끝나면 파이프 입구를 잠금 (더 보낼 데이터가 없음을 커널에 알림)
  stream.end();

  // 파이프에 남은 마지막 잔여 데이터까지 디스크에 안전하게 기록될 때까지 완벽히 대기
  await finished(stream);

  console.timeEnd("5_OptimalStream_작업시간");
  console.log(
    "✅ 완벽하게 완료! (메모리 안전, 메인 스레드 논블로킹, 압도적 속도)\n",
  );
}

// =========================================================================
// 🚀 [실행부] 여기서 테스트하고 싶은 함수의 주석을 하나만 해제하고 실행하세요!
// =========================================================================

// runPromiseVersion();   // 1번 테스트: 꽤 오랜 시간이 걸리는 것을 직접 확인해 보세요.
// runCallbackVersion();  // 2번 테스트: (위험) 실행 즉시 종료되지만, 백그라운드에서 메모리가 치솟습니다.
// runSyncVersion();      // 3번 테스트: 속도는 빠르나 이 코드가 도는 동안 다른 작업이 불가능해집니다.
// runBadStream();        // 4번 테스트: 속도는 0.1초 만에 끝나지만, 2번과 동일하게 메모리가 위험해집니다.

runOptimalStream(); // 5번 테스트: 🏆 우리가 스트림을 써야만 하는 이유입니다! 가장 완벽한 형태입니다.
