/**
 * [fragmentationTest.mjs]
 * 8강: 기계적 칼질에 의한 데이터 조각 절단(파편화) 현상 직접 눈으로 확인하기
 * (파일 생성 완료를 완벽히 기다린 후 읽기를 시작합니다)
 */
import fs from "node:fs/promises";
import { finished } from "node:stream/promises";

async function runFragmentationMaster() {
  const SOURCE_FILE = "massive_server_logs.txt";
  const TOTAL_LOGS = 100000; // 테스트를 위해 10만 개로 축소 (약 8MB)

  // =====================================================================
  // Phase 1: 거대한 원본 로그 파일 생성 (동기적 완벽 보장)
  // =====================================================================
  console.log("▶️ 1. 거대한 원본 로그 파일 생성 중...");
  console.time("생성_시간");

  const fileHandleWrite = await fs.open(SOURCE_FILE, "w");
  const writeStream = fileHandleWrite.createWriteStream();

  for (let i = 0; i < TOTAL_LOGS; i++) {
    const logType = i % 2 === 0 ? "INFO" : "ERROR";
    const message =
      logType === "INFO"
        ? "데이터 처리가 정상적으로 완료되었습니다."
        : "Network Card Connection Timeout 발생!";
    // 각 로그는 이중 공백("  ")으로 구분
    const data = `[${logType}] 시스템 식별자 ${i} - ${message}  `;

    if (!writeStream.write(data)) {
      await new Promise((resolve) => writeStream.once("drain", resolve));
    }
  }

  writeStream.end();
  // 핵심: 파일이 디스크에 '완벽하게' 쓰여질 때까지 기다립니다.
  await finished(writeStream);
  await fileHandleWrite.close();

  console.timeEnd("생성_시간");
  console.log("✅ 로그 파일 생성 완료!\n");

  // =====================================================================
  // Phase 2: 취수 펌프 가동 및 파편화 현상 관찰
  // =====================================================================
  console.log(
    "▶️ 2. 취수 펌프 가동: 64KB 기계적 칼질의 참사(데이터 절단) 확인",
  );

  const fileHandleRead = await fs.open(SOURCE_FILE, "r");
  // 읽기 펌프 (64KB 단위 기계적 칼질)
  const readStream = fileHandleRead.createReadStream({
    highWaterMark: 64 * 1024,
  });

  let chunkCount = 0;
  let cutFragment = ""; // 잘린 조각을 저장해둘 변수

  readStream.on("data", (chunk) => {
    chunkCount++;

    // 이진 데이터를 문자열로 번역하고 이중 공백으로 자름
    const logs = chunk.toString("utf-8").split("  ");
    cutFragment = logs[logs.length - 1]; // 배열의 가장 마지막 요소(절단된 꼬리) 저장

    console.log(`\n--- [${chunkCount}번째 64KB 조각 분석] ---`);
    console.log("🟢 첫 번째 조각 (멀쩡함):", logs[0]);
    console.log("🚨 마지막 조각 (절단됨):", cutFragment);

    // 첫 번째 조각의 파편화만 확인하기 위해 펌프 즉시 강제 정지
    readStream.pause();

    console.log(
      "\n⚠️ 펌프가 자르기 전에 '온전한 문장인가?(Yes/No)'를 묻지 않고",
    );
    console.log("기계적으로 썰어버렸기 때문에 문장이 반 토막 났습니다!");
    console.log("이 상태로는 절대 정확한 로그 필터링(if문)을 할 수 없습니다!");

    // 테스트 종료를 위해 스트림 파괴
    readStream.destroy();
  });

  // =====================================================================
  // Phase 3: 스트림 파괴 후 최종 확인 출력 및 클린업
  // =====================================================================
  readStream.on("close", async () => {
    await fileHandleRead.close();

    // ✨ 수강생의 눈길을 사로잡을 최종 점검 출력 ✨
    console.log("\n========================================================");
    console.log(
      "🔥 [최종 점검] 방금 두 눈으로 확인하신 끔찍하게 잘린 조각입니다:",
    );
    console.log(`👉 "${cutFragment}"`);
    console.log("========================================================\n");

    console.log(
      "📂 팁: 테스트가 끝났습니다! 작업 폴더에 남겨진 'massive_server_logs.txt' 파일을 직접 열어보세요!",
    );
  });
}

// 스크립트 실행
runFragmentationMaster().catch(console.error);
