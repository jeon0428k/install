/**
 * [manualBufferCopyMaster.mjs]
 * 12강: 스트림 없는 수동 버퍼 제어 파이프라인 (최종 마스터 스크립트)
 * (1) 500MB 거대 파일 생성 -> (2) O(1) 공간 복잡도로 수동 복사
 */
import fs from "node:fs/promises";
import { finished } from "node:stream/promises";

async function runManualBufferMaster() {
  const SOURCE_FILE = "source.txt";
  const TARGET_FILE = "target.txt";
  
  // 약 500MB 크기의 데이터를 생성합니다. 
  // (테스트 환경에 따라 10초~30초 정도 소요될 수 있습니다)
  const TOTAL_LOGS = 5000000; 

  // =====================================================================
  // Phase 1: 스트레스 테스트용 500MB 거대 원본 파일 생성 (안전한 스트림 사용)
  // =====================================================================
  console.log("▶️  1. 500MB 거대 원본 파일(source.txt) 생성 중... (잠시만 기다려주세요)");
  console.time("생성_소요시간");

  const sourceFileHandle = await fs.open(SOURCE_FILE, "w");
  const writeStream = sourceFileHandle.createWriteStream();

  for (let i = 0; i < TOTAL_LOGS; i++) {
    const data = `[LOG] 데이터 스트리밍 및 파일 복사 테스트용 더미 텍스트입니다. 현재 인덱스: ${i}\n`;
    
    // 백프레셔 제어: 쓰기 버퍼가 꽉 차면 비워질 때(drain)까지 기다립니다.
    if (!writeStream.write(data)) {
      await new Promise((resolve) => writeStream.once("drain", resolve));
    }
  }

  writeStream.end();
  await finished(writeStream);       // 디스크 쓰기가 완전히 끝날 때까지 대기
  await sourceFileHandle.close();    // 파일 디스크립터 자원 반납

  console.timeEnd("생성_소요시간");
  console.log("✅ 원본 파일 생성 완료!\n");

  // =====================================================================
  // Phase 2: 기계의 심장을 직접 통제하는 수동 버퍼 복사 (O(1) 공간 복잡도)
  // =====================================================================
  console.log("▶️  2. 수동 버퍼 제어를 통한 파일 복사 시작");
  console.log("💡 [관전 포인트] 작업 관리자를 열고 Node.js의 RAM 점유율이 30MB 안팎에서 평온한지 확인하세요!");
  console.time("복사_소요시간");

  // 1. 원본 읽기 파이프와 목적지 쓰기 파이프 개통
  const fileReader = await fs.open(SOURCE_FILE, "r");
  const fileWriter = await fs.open(TARGET_FILE, "w");

  // 2. 메모리 고정: 16KB 크기의 빈 바가지 하나만 생성 (무한 재사용)
  const CHUNK_SIZE = 16384;
  const sharedBuffer = Buffer.alloc(CHUNK_SIZE);

  try {
    let readCount = -1;
    let totalCopiedBytes = 0;

    // 3. 수동 펌프질 시작 (무한 루프)
    while (readCount !== 0) {
      // 4. 원본 파일에서 딱 16KB(바가지 크기)만큼만 데이터 퍼 올리기
      const { bytesRead } = await fileReader.read(sharedBuffer, 0, CHUNK_SIZE, null);
      readCount = bytesRead;

      // 5. 파일 바닥(EOF)에 도달해 퍼 올린 데이터가 없다면 펌프질 종료
      if (readCount === 0) break;

      // 6. 찌꺼기 널(Null) 바이트 제거를 위한 정밀 슬라이싱 
      // (메모리를 새로 복사하지 않고 유효 구간만 바라보는 가벼운 View 생성)
      const validBuffer = sharedBuffer.subarray(0, readCount);
      
      // 7. 찌꺼기가 제거된 깨끗한 데이터를 목적지 파일에 쏟아붓기
      await fileWriter.write(validBuffer);
      
      totalCopiedBytes += readCount;
    }

    console.log(`\n🎉 [복사 완료] 총 복사된 용량: ${(totalCopiedBytes / 1024 / 1024).toFixed(2)} MB`);

  } finally {
    // 8. ⭐️ 시스템 자원(파일 디스크립터) 반납 
    // 에러가 나더라도 무조건 실행되어 고스트 프로세스를 막는 필수 로직입니다.
    await fileReader.close();
    await fileWriter.close();
  }

  console.timeEnd("복사_소요시간");

  // =====================================================================
  // Phase 3: 테스트 종료 안내
  // =====================================================================
  console.log("\n========================================================");
  console.log("🔥 [테스트 성공] 500MB의 거대 파일을 복사하는 동안");
  console.log("RAM 점유율이 완벽하게 수평을 유지했습니다! (공간 복잡도 O(1) 달성)");
  console.log("========================================================\n");
  
  // 팁 안내
  console.log("📂 팁: 테스트가 끝났습니다! 컴퓨터 용량 확보를 위해 생성된 ");
  console.log("       'source.txt'와 'target.txt' 파일을 직접 삭제해 주셔도 좋습니다.");
}

// 스크립트 실행 및 에러 핸들링
runManualBufferMaster().catch(console.error);