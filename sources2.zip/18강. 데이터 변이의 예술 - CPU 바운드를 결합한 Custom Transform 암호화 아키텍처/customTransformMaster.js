import { Transform } from "node:stream";
import { open } from "node:fs/promises";
import { pipeline } from "node:stream/promises";

// =====================================================================
// 1. 암호화 엔진 (Encryption Transform Stream)
// =====================================================================
class SmartCipherEngine extends Transform {
  constructor({ totalFileSize }) {
    super();
    this.totalFileSize = totalFileSize;
    this.processedBytes = 0;
    this.loggedPercentage = 0;
  }

  _transform(chunk, encoding, callback) {
    // [CS 최적화] In-place Mutation으로 메모리 할당 없이 데이터 변이
    for (let i = 0; i < chunk.length; ++i) {
      chunk[i] = chunk[i] + 1; // +1 시프트 연산
    }

    this.processedBytes += chunk.length;

    // 진행률 계산 및 콘솔 I/O 스로틀링
    const currentPercentage = Math.min(
      Math.floor((this.processedBytes / this.totalFileSize) * 100),
      100,
    );

    if (currentPercentage > this.loggedPercentage) {
      console.log(`🔒 대용량 파일 암호화 진행률: ${currentPercentage}%`);
      this.loggedPercentage = currentPercentage;
    }

    callback(null, chunk);
  }
}

// =====================================================================
// 2. 복호화 엔진 (Decryption Transform Stream)
// =====================================================================
class SmartDecipherEngine extends Transform {
  constructor({ totalFileSize }) {
    super();
    this.totalFileSize = totalFileSize;
    this.processedBytes = 0;
    this.loggedPercentage = 0;
  }

  _transform(chunk, encoding, callback) {
    // [CS 최적화] In-place Mutation으로 암호문 원상 복구
    for (let i = 0; i < chunk.length; ++i) {
      chunk[i] = chunk[i] - 1; // -1 역방향 시프트 연산
    }

    this.processedBytes += chunk.length;
    const currentPercentage = Math.min(
      Math.floor((this.processedBytes / this.totalFileSize) * 100),
      100,
    );

    if (currentPercentage > this.loggedPercentage) {
      console.log(`🔓 대용량 파일 복호화 진행률: ${currentPercentage}%`);
      this.loggedPercentage = currentPercentage;
    }

    callback(null, chunk);
  }
}

// =====================================================================
// 3. 파이프라인 가동 메인 로직
// =====================================================================
async function runEncryptionPipeline() {
  console.time("대용량 파일 암호화 파이프라인 가동 시간");

  const sourceFilePath = "read_source.txt";
  const targetFilePath = "encrypted_destination.txt";

  const readHandle = await open(sourceFilePath, "r");
  const { size: totalFileSize } = await readHandle.stat();
  const writeHandle = await open(targetFilePath, "w");

  const readStream = readHandle.createReadStream();
  const writeStream = writeHandle.createWriteStream();

  const cipherEngine = new SmartCipherEngine({ totalFileSize });

  console.log(
    `\\n🚀 총 ${(totalFileSize / 1024 / 1024).toFixed(2)} MB 데이터 암호화를 시작합니다...`,
  );

  try {
    await pipeline(readStream, cipherEngine, writeStream);
    console.log(`\\n✅ 대용량 파일 암호화가 성공적으로 종료되었습니다!`);
  } catch (error) {
    console.error("🚨 파이프라인 붕괴 에러:", error);
  } finally {
    await readHandle.close();
    await writeHandle.close();
    console.timeEnd("대용량 파일 암호화 파이프라인 가동 시간");
  }
}

async function runDecryptionPipeline() {
  console.time("대용량 파일 복호화 파이프라인 가동 시간");

  const sourceFilePath = "encrypted_destination.txt";
  const targetFilePath = "decrypted_destination.txt";

  const readHandle = await open(sourceFilePath, "r");
  const { size: totalFileSize } = await readHandle.stat();
  const writeHandle = await open(targetFilePath, "w");

  const readStream = readHandle.createReadStream();
  const writeStream = writeHandle.createWriteStream();

  const decipherEngine = new SmartDecipherEngine({ totalFileSize });

  console.log(
    `\\n🚀 총 ${(totalFileSize / 1024 / 1024).toFixed(2)} MB 데이터 복호화를 시작합니다...`,
  );

  try {
    await pipeline(readStream, decipherEngine, writeStream);
    console.log(`\\n✅ 대용량 파일 복호화가 성공적으로 종료되었습니다!`);
  } catch (error) {
    console.error("🚨 파이프라인 붕괴 에러:", error);
  } finally {
    await readHandle.close();
    await writeHandle.close();
    console.timeEnd("대용량 파일 복호화 파이프라인 가동 시간");
  }
}

// ---------------------------------------------------------------------
// 🚀 최상위 실행부 (Top-level Await)
// ---------------------------------------------------------------------
await runEncryptionPipeline();
await runDecryptionPipeline();
