/**
 * [writableMaster.js]
 * 5강: Writable Stream의 내부 버퍼 확인 및 백프레셔 완벽 제어
 */
import fs from "node:fs/promises";
import { finished } from "node:stream/promises";

const TARGET_FILE = "server_logs_safe.txt";
const MAX_ITERATION = 1000000;

async function runWritableStreamMaster() {
  console.log("▶️ 1. 스트림 내부 버퍼(RAM) 상태 확인 실험 시작\\n");

  // 1. 파일 핸들 확보 및 파이프 생성
  const fileHandle = await fs.open(TARGET_FILE, "w");
  const stream = fileHandle.createWriteStream();

  // 2. 초기 상태 확인
  console.log(
    `[초기 상태] 최대 수위선: ${stream.writableHighWaterMark} Bytes (약 16KB)`,
  );
  console.log(`[초기 상태] 현재 채워진 물: ${stream.writableLength} Bytes`);

  // 3. 테스트 데이터 삽입
  const testData = Buffer.from("스트림 원리 테스트", "utf-8"); // 25 Bytes
  stream.write(testData);
  console.log(
    `[데이터 투입 후] 현재 채워진 물: ${stream.writableLength} Bytes\\n`,
  );

  console.log("▶️ 2. 100만 번 백프레셔 방어 테스트 시작 (약 78MB 데이터)\\n");
  console.time("총_소요_시간");

  let drainCount = 0; // drain 이벤트 발생 횟수 추적용

  // 4. 안전한 반복문 시작
  for (let i = 0; i < MAX_ITERATION; i++) {
    const data = `[시스템 로그] 유저 ${i}님의 데이터 처리가 완료되었습니다.\\n`;

    // 버퍼가 16KB를 초과하여 꽉 찼을 때 (false 반환)
    if (!stream.write(data)) {
      drainCount++; // 물 빼기 작업 카운트 증가

      // 버퍼가 다 비워질 때까지 반복문을 멈추고 대기! (핵심)
      await new Promise((resolve) => stream.once("drain", resolve));
    }
  }

  // 5. 파이프 종료 및 안전한 자원 반납
  stream.end();
  await finished(stream);
  await fileHandle.close();

  console.timeEnd("총_소요_시간");
  console.log(`\\n✅ 성공적으로 완료되었습니다!`);
  console.log(`📊 발생한 병목(Drain) 횟수: 총 ${drainCount}회`);
  console.log(
    `-> 100만 번의 요청을 단 ${drainCount + 1}번의 디스크 쓰기(System Call)로 압축했습니다.`,
  );
}

// 스크립트 실행
runWritableStreamMaster().catch(console.error);
