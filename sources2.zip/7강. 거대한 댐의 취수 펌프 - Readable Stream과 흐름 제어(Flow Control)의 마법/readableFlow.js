/**
 * [readableFlow.mjs]
 * 7강: Readable Stream 펌프 가동 및 완벽한 흐름 제어(Flow Control) 테스트
 */
import fs from "node:fs/promises";

async function runReadableFlowMaster() {
  console.log(
    "▶️ [7강 마스터 스크립트] 거대한 파일 복사 흐름 제어 시뮬레이션\\n",
  );

  const SOURCE_FILE = "test_source.txt";
  const DEST_FILE = "test_dest.txt";

  // 실험을 위해 1MB(약 100만 바이트) 크기의 가짜 원본 파일 생성 (fs.writeFile 메서드 활용)
  console.log("1. 임시 원본 파일(댐) 생성 중...");
  await fs.writeFile(SOURCE_FILE, "0123456789".repeat(100000));

  // 파일 접근 권한 요청 (번호표 발급)
  const fileHandleRead = await fs.open(SOURCE_FILE, "r");
  const fileHandleWrite = await fs.open(DEST_FILE, "w");

  // 속성 제어: 실험을 위해 펌프(읽기)는 64KB, 하수구(쓰기)는 16KB(기본값)로 설정
  const streamRead = fileHandleRead.createReadStream({
    highWaterMark: 64 * 1024,
  });
  const streamWrite = fileHandleWrite.createWriteStream();

  let chunkCount = 0;
  let pauseCount = 0;

  console.time("복사_소요_시간");

  // 1. 이벤트 등록: data 이벤트를 감지하는 순간 펌프 가동
  streamRead.on("data", (chunk) => {
    chunkCount++;
    console.log(
      ` 💧 [펌프 가동] ${chunkCount}번째 물 퍼 올림! (크기: ${chunk.length} Bytes)`,
    );

    // 백프레셔 감지: write 메서드의 반환값이 false인가?
    if (!streamWrite.write(chunk)) {
      pauseCount++;
      console.log(
        `    🚨 [경고] 하수구 꽉 참! -> streamRead.pause() 호출! 펌프 강제 정지 🛑`,
      );
      // 메서드 호출: RAM 유입 강제 차단
      streamRead.pause();
    }
  });

  // 2. 백프레셔 해소: drain 이벤트를 통해 물이 싹 다 빠져나갔음을 감지
  streamWrite.on("drain", () => {
    console.log(
      `    🔔 [알림] 하수구 물 다 빠짐(drain) -> streamRead.resume() 호출! 펌프 재가동 🟢`,
    );
    // 메서드 호출: 멈춘 펌프 다시 회전
    streamRead.resume();
  });

  // 3. 작업 종료 알림: end 이벤트를 통해 댐 바닥 확인
  streamRead.on("end", async () => {
    console.log("\\n✅ [종료] 댐 바닥 도착. 모든 데이터 복사 완료!");
    // 메서드: 더 보낼 물이 없다고 선언하고 파이프 닫기 절차 진입
    streamWrite.end();

    // 메서드: 사용이 끝난 읽기 파일 디스크립터(번호표) 운영체제에 반환
    await fileHandleRead.close();

    // finish 이벤트: 쓰기 파이프가 논리적으로 완벽히 닫혔음을 보장
    streamWrite.on("finish", async () => {
      // 쓰기 파일 디스크립터(번호표) 운영체제에 반환 (메모리 누수 방지)
      await fileHandleWrite.close();
      console.timeEnd("복사_소요_시간");
      console.log(
        `📊 요약: 총 ${chunkCount}회 펌프질, ${pauseCount}회 비상 정지(메모리 방어 성공)`,
      );

      // 메서드: 실험용 임시 파일 삭제 클린업 (unlink)
      await fs.unlink(SOURCE_FILE);
      await fs.unlink(DEST_FILE);
    });
  });
}

// 스크립트 실행
runReadableFlowMaster().catch(console.error);
