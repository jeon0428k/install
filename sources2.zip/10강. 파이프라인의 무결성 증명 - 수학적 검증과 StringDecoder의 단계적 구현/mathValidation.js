/**
 * [mathValidation.js]
 * 10강: 데이터 절단의 수학적 증명과 무결성 검증 아키텍처 (최종 완성본)
 */
import fs from "node:fs/promises";
import { StringDecoder } from "node:string_decoder";
import { finished } from "node:stream/promises";

// [도우미 함수] 정규식으로 시스템 식별자 번호만 안전하게 추출
const extractId = (logString) => {
  const match = logString?.match(/시스템 식별자 (\d+)/);
  return match ? Number(match[1]) : NaN;
};

async function runMathValidationMaster() {
  const SOURCE_FILE = "massive_server_logs.txt";
  const DEST_FILE = "filtered_errors.txt";
  const TOTAL_LOGS = 100000;

  // =====================================================================
  // Phase 1: 거대한 원본 로그 파일 생성
  // =====================================================================
  console.log("▶️  1. 원본 로그 파일 생성 중...");
  console.time("생성_시간");
  const fileHandleWriteOrigin = await fs.open(SOURCE_FILE, "w");
  const writeStreamOrigin = fileHandleWriteOrigin.createWriteStream();

  for (let i = 0; i < TOTAL_LOGS; i++) {
    // 3의 배수이거나 10의 배수일 때 ERROR 로그로 생성
    const logType = i % 3 === 0 || i % 10 === 0 ? "ERROR" : "INFO";
    const message =
      logType === "INFO"
        ? "데이터 처리가 정상적으로 완료되었습니다."
        : "Network Card Connection Timeout 발생!";

    const data = `[${logType}] 시스템 식별자 ${i} - ${message}  `;

    if (!writeStreamOrigin.write(data)) {
      await new Promise((resolve) => writeStreamOrigin.once("drain", resolve));
    }
  }

  writeStreamOrigin.end();
  await finished(writeStreamOrigin);
  await fileHandleWriteOrigin.close();
  console.timeEnd("생성_시간");
  console.log("\n✅ 원본 파일 생성 완료!\n");

  // =====================================================================
  // Phase 2: 수학적 증명 필터링 아키텍처 가동
  // =====================================================================
  console.log("▶️  2. 취수 펌프 가동 및 수학적 무결성 필터링 시작...");
  console.time("로그_분석_소요시간");

  const fileHandleRead = await fs.open(SOURCE_FILE, "r");
  const fileHandleWriteDest = await fs.open(DEST_FILE, "w");

  const streamRead = fileHandleRead.createReadStream({
    highWaterMark: 64 * 1024,
  });
  const streamWrite = fileHandleWriteDest.createWriteStream();

  const decoder = new StringDecoder("utf-8"); // 바이트 절단 방지
  let leftover = ""; // 자투리 보관소
  let extractedCount = 0;

  streamRead.on("data", (chunk) => {
    // 디코더로 번역 후 이중 공백 분리
    const logs = decoder.write(chunk).split("  ");

    // [머리 검증] 첫 번째 번호와 두 번째 번호 비교
    const firstId = extractId(logs[0]);
    const secondId = extractId(logs[1]);

    if (firstId !== secondId - 1) {
      // 파편화 증명됨!
      if (leftover !== "") logs[0] = leftover + logs[0];
    }

    // [꼬리 검증] 끝에서 두 번째 번호와 마지막 번호 비교
    const lastId = extractId(logs[logs.length - 1]);
    const secondLastId = extractId(logs[logs.length - 2]);

    if (secondLastId + 1 !== lastId) {
      // 파편화 증명됨!
      leftover = logs.pop(); // 이때만 대피!
    }

    // [무결성 필터링]
    logs.forEach((log) => {
      const id = extractId(log);
      // 조건: 10의 배수이면서 [ERROR] 인 것만 추출
      if (id % 10 === 0 && log.includes("[ERROR]")) {
        extractedCount++;

        // 💡 새롭게 추가된 부분: 어떤 에러가 검증되어 파일에 기록되는지 콘솔에 출력합니다.
        // (단, 터미널이 1만 줄로 도배되어 마비되는 것을 막기 위해 샘플만 출력합니다)
        if (extractedCount <= 3 || extractedCount % 2500 === 0) {
          console.log(`   🔎 [검증 완료 및 저장] 추출된 로그: "${log}"`);
        } else if (extractedCount === 4) {
          console.log(
            `   ... (중략: 완벽하게 복원된 에러 로그들을 목적지 파일에 고속으로 쓰는 중입니다) ...`,
          );
        }

        if (!streamWrite.write(log + "  ")) {
          streamRead.pause(); // 백프레셔 방어
        }
      }
    });
  });

  streamWrite.on("drain", () => streamRead.resume());

  // =====================================================================
  // Phase 3: 종료 및 자원 반납
  // =====================================================================
  streamRead.on("end", async () => {
    const lastSplitId = extractId(leftover);
    if (lastSplitId % 10 === 0 && leftover.includes("[ERROR]")) {
      extractedCount++;
      console.log(
        `   🔎 [최후 검증 완료 및 저장] 마지막 꼬리 로그: "${leftover}"`,
      );
      const finalString = leftover + decoder.end();
      streamWrite.write(finalString + "  ");
    }

    streamWrite.end();
    await finished(streamWrite);

    await fileHandleRead.close();
    await fileHandleWriteDest.close();

    console.log("\n");
    console.timeEnd("로그_분석_소요시간");
    console.log("\n========================================================");
    console.log("🎉 [최종 리포트] 수학적 검증 분석 작업 완료!");
    console.log(
      `- 추출된 에러 로그: 정확히 ${extractedCount.toLocaleString()}개`,
    );
    console.log("========================================================\n");

    console.log(
      "📂 팁: 작업 폴더에 남겨진 'filtered_errors.txt' 파일을 직접 열어보세요!",
    );
  });
}

runMathValidationMaster().catch(console.error);
