import { writeFileSync } from "node:fs";

console.time("파일 생성 소요 시간");
console.log("⏳ 거대한 원본 데이터 파일(read_source.txt) 생성을 시작합니다...");

const targetFilePath = "read_source.txt";
const totalLines = 1000000; // 100만 줄의 텍스트 생성
let dummyData = "";

// 100만 줄의 문자열을 메모리에서 빠르게 조립합니다.
for (let i = 0; i < totalLines; i++) {
  dummyData += `이것은 Custom Duplex Stream의 읽기 엔진을 테스트하기 위한 거대한 원본 데이터의 ${i}번째 줄입니다.\\n`;
}

// 조립된 거대한 문자열을 하드디스크에 한 번에 기록합니다.
writeFileSync(targetFilePath, dummyData, "utf-8");

console.log(`\n✅ 성공적으로 ${targetFilePath} 파일이 생성되었습니다!`);
console.log(`- 대략적인 용량: 약 ${(Buffer.byteLength(dummyData) / 1024 / 1024).toFixed(2)} MB`);
console.timeEnd("파일 생성 소요 시간");