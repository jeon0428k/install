import { Duplex } from "node:stream";
import { open, read, write, close } from "node:fs";

// =====================================================================
// 1. 완벽하게 통제된 Custom Duplex Stream 클래스 정의 (듀얼 엔진)
// =====================================================================
class SmartDuplexController extends Duplex {
  constructor({ 
    readableHighWaterMark, 
    writableHighWaterMark, 
    readSourcePath, 
    writeDestinationPath 
  }) {
    // 부모 클래스인 Duplex에게 읽기/쓰기 물탱크의 임계점(수위)을 각각 독립적으로 전달
    super({ readableHighWaterMark, writableHighWaterMark });

    // 물리적 디스크의 원본 파일(읽기)과 목적지 파일(쓰기) 경로 보관
    this.readSourcePath = readSourcePath;
    this.writeDestinationPath = writeDestinationPath;
    
    // OS 커널로부터 부여받을 파일 접근 권한 번호표(File Descriptor) 공간
    this.readFd = null;
    this.writeFd = null;

    // [쓰기 최적화] 무거운 디스크 I/O를 막기 위해 메모리상에 데이터를 모아둘 램 버퍼 배열
    this.ramBuffer = [];
    this.bufferedBytes = 0; // 램 버퍼에 모인 데이터의 총 바이트 수 추적

    // [벤치마크용] 실제 물리적 디스크 I/O 시스템 콜이 발생한 횟수 카운터
    this.ioReadCount = 0;
    this.ioWriteCount = 0;
  }

  // -------------------------------------------------------------------
  // 생명주기 1: 권한 획득 (파이프라인 개통 전 하드웨어 자원 선점)
  // -------------------------------------------------------------------
  _construct(callback) {
    // 1. 읽기 전용("r")으로 원본 파일 권한 요청
    open(this.readSourcePath, "r", (readError, readFd) => {
      if (readError) return callback(readError); // 에러 시 즉시 파이프라인 가동 중단
      
      this.readFd = readFd; // 읽기 티켓 보관

      // 2. 쓰기 전용("w")으로 목적지 파일 권한 연쇄 요청
      open(this.writeDestinationPath, "w", (writeError, writeFd) => {
        if (writeError) return callback(writeError);
        
        this.writeFd = writeFd; // 쓰기 티켓 보관
        
        // 3. 듀얼 엔진 권한 획득 성공! 빈 콜백을 호출하여 정식 가동 승인
        callback();
      });
    });
  }

  // -------------------------------------------------------------------
  // 생명주기 2-1: 양방향 심장 가동 - 쓰기 엔진 (지연 쓰기 아키텍처)
  // -------------------------------------------------------------------
  _write(chunk, encoding, callback) {
    // 1. 즉시 하드디스크에 쓰지 않고, 램 버퍼 배열에 데이터를 가볍게 쌓아둠
    this.ramBuffer.push(chunk);
    this.bufferedBytes += chunk.length;

    // 2. 모인 데이터가 우리가 설정한 물탱크 수위(writableHighWaterMark)를 넘었는가?
    if (this.bufferedBytes > this.writableHighWaterMark) {
      // [CS 극한 최적화] 파편화된 배열 조각들을 메모리에서 단일 버퍼로 뭉침 (Buffer.concat)
      write(
        this.writeFd, 
        Buffer.concat(this.ramBuffer), // 뭉친 거대 덩어리를 단 1번의 시스템 콜로 디스크에 기록!
        (error) => {
          if (error) return callback(error);

          // 기록 완료 후 램 버퍼 배열 및 바이트 용량 초기화
          this.ramBuffer = [];
          this.bufferedBytes = 0;
          ++this.ioWriteCount; // 물리적 쓰기 카운터 증가
          callback(); // 쓰기 완료 보고
        }
      );
    } else {
      // 수위를 넘지 않았다면? 시스템 콜 없이 즉시 메인 루프로 복귀 (초고속 논블로킹)
      callback(); 
    }
  }

  // -------------------------------------------------------------------
  // 생명주기 2-2: 양방향 심장 가동 - 읽기 엔진 (초고속 메모리 추출)
  // -------------------------------------------------------------------
  _read(size) {
    // 1. [성능 튜닝] 초기화(Zero-fill) 과정을 생략하여 CPU 낭비를 없앤 빈 바가지 생성
    const tempBuffer = Buffer.allocUnsafe(size);

    // 2. OS 커널에 디스크 읽기 명령 (오프셋 null 지정으로 커널이 포인터 자동 전진)
    read(this.readFd, tempBuffer, 0, size, null, (error, bytesRead) => {
      if (error) return this.destroy(error);

      // 3. 디스크에서 무사히 퍼 올렸다면?
      if (bytesRead > 0) {
        // [CS 극한 최적화] 메모리 복사(Copy) 없이 가상의 창문(View)만 조절하여 순수 데이터 추출
        const actualData = tempBuffer.subarray(0, bytesRead);
        ++this.ioReadCount; // 물리적 읽기 카운터 증가
        
        this.push(actualData); // 파이프라인으로 데이터 방출
      } else {
        // bytesRead가 0이면 파일 끝(EOF). null을 뱉어 펌프 정지 선언
        this.push(null);
      }
    });
  }

  // -------------------------------------------------------------------
  // 생명주기 3: 잔여물 처리 (파이프라인 종료 선언 시)
  // -------------------------------------------------------------------
  _final(callback) {
    // 스트림 쓰기 종료(end)가 호출되었을 때, 램 버퍼에 수위를 넘지 못해 고여있는 데이터가 있다면?
    if (this.bufferedBytes > 0) {
      // 남은 찌꺼기들을 하나로 뭉쳐 마지막으로 디스크에 영구 밀봉
      write(
        this.writeFd,
        Buffer.concat(this.ramBuffer),
        (error) => {
          if (error) return callback(error);

          this.ramBuffer = [];
          this.bufferedBytes = 0;
          ++this.ioWriteCount;
          callback();
        }
      );
    } else {
      callback();
    }
  }

  // -------------------------------------------------------------------
  // 생명주기 4: 자원 반납 (스트림 파괴 시 최후 실행)
  // -------------------------------------------------------------------
  _destroy(error, callback) {
    // 최종 벤치마크 결과 출력
    console.log(`\n📊 듀얼 엔진 하드웨어 벤치마크 결과`);
    console.log(`- 물리적 디스크 Read I/O 횟수: ${this.ioReadCount}회`);
    console.log(`- 물리적 디스크 Write I/O 횟수: ${this.ioWriteCount}회`);

    // 쓰기 티켓 반납 헬퍼 함수
    const closeWriteDescriptor = (readCloseError) => {
      if (this.writeFd !== null) {
        close(this.writeFd, (writeCloseError) => {
          callback(readCloseError || writeCloseError || error);
        });
      } else {
        callback(readCloseError || error);
      }
    };

    // [중요] 읽기 티켓을 먼저 반납하고, 완료된 후 쓰기 티켓을 연쇄적으로 반납 (자원 누수 방어)
    if (this.readFd !== null) {
      close(this.readFd, (readCloseError) => {
        closeWriteDescriptor(readCloseError);
      });
    } else {
      closeWriteDescriptor(null);
    }
  }
}

// =====================================================================
// 2. 벤치마크 실행 및 이벤트 리스닝 로직 (논블로킹 양방향 통신 검증)
// =====================================================================
console.time("Duplex Dual Engine Time");

// 64KB의 물탱크를 가진 듀얼 엔진 조립
const duplex = new SmartDuplexController({
  readableHighWaterMark: 1024 * 64, // 64KB (디스크 블록 최적화 사이즈)
  writableHighWaterMark: 1024 * 64, // 64KB
  readSourcePath: "read_source.txt",
  writeDestinationPath: "write_destination.txt",
});

let currentIndex = 0;
const MAX_WRITE_COUNT = 100000;

// [쓰기 로직] 10만 번의 연속 쓰기 요청을 처리하는 함수
const executeWriting = () => {
  while (currentIndex < MAX_WRITE_COUNT) {
    const chunk = Buffer.from(` 듀얼 엔진 쓰기 테스트 ${currentIndex} \n`, "utf-8");

    // 마지막 인덱스에 도달하면 스트림 종료 선언 (_final 트리거)
    if (currentIndex === MAX_WRITE_COUNT - 1) {
      return duplex.end(chunk);
    }

    // 데이터를 밀어넣음. 물탱크가 가득 차면 false 반환 (백프레셔 발생)
    const canKeepWriting = duplex.write(chunk);

    if (!canKeepWriting) {
      // 램 폭발을 막기 위해 루프를 깨고 메인 스레드에 제어권 반환!
      break;
    }
    ++currentIndex;
  }
};

// 최초 쓰기 폭격 시작!
executeWriting();

// 쓰기 물탱크의 물이 다 빠져서 다시 쓸 수 있게 되면 발생하는 이벤트
duplex.on("drain", () => {
  executeWriting(); // 멈췄던 루프 재개
});

let totalChunks = 0;

// [핵심 트리거] 'data' 리스너를 다는 순간, 읽기 펌프(_read)가 백그라운드에서 가동 시작!
duplex.on("data", (chunk) => {
  ++totalChunks; // 읽기 펌프가 작동한 횟수 누적
});

// 읽기 측 끝 도달 (상대방 데이터 수신 완료)
duplex.on("end", () => {
  console.log(`\n✅ [Read 측] 모든 데이터 퍼 올리기 완료! (Chunk 분할 펌핑: ${totalChunks}회)`);
});

// 쓰기 측 끝 도달 (내 데이터 전송 완벽 완료)
duplex.on("finish", () => {
  console.log(`✅ [Write 측] 모든 데이터 디스크 쓰기 완료!`);
});

// OS 권한 자원 반납까지 모두 완료된 최후의 순간
duplex.on("close", () => {
  console.log(`✅ 완벽한 자원 반납 종결 (File Lock 방어 성공)`);
  console.timeEnd("Duplex Dual Engine Time");
});